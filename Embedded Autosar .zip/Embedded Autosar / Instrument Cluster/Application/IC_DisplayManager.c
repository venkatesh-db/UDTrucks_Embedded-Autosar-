/**
 * @file IC_DisplayManager.c
 * @brief Instrument Cluster Display Manager - RACE CONDITION EXAMPLE
 * @version 1.0
 * @date 2025-11-07
 * 
 * ISSUE: This file demonstrates a typical race condition that can cause
 * the Instrument Cluster to become unresponsive (dead state)
 */

#include "IC_DisplayManager.h"
#include "Rte_IC_DisplayManager.h"
#include <string.h>
#include <stdbool.h>

/* Global shared display buffer - RACE CONDITION HAZARD */
static DisplayBuffer_t g_DisplayBuffer;
static volatile bool g_BufferLock = false;
static uint32 g_UpdateCounter = 0;

/* PROBLEMATIC: No proper synchronization mechanism */
static bool g_DisplayUpdateInProgress = false;

/**
 * @brief RACE CONDITION SCENARIO 1: Shared Buffer Access
 * Multiple runnables can access this simultaneously causing corruption
 */
void IC_DisplayManager_UpdateSpeed(float speed)
{
    /* PROBLEM: No atomic operation or mutex protection */
    if (!g_DisplayUpdateInProgress)  // <- RACE CONDITION HERE
    {
        g_DisplayUpdateInProgress = true;  // <- Another thread can interrupt here
        
        /* Critical section without proper protection */
        g_DisplayBuffer.speedValue = speed;
        g_DisplayBuffer.speedValid = true;
        g_UpdateCounter++;
        
        /* Simulate processing delay where interruption can occur */
        for (volatile int i = 0; i < 1000; i++); // Delay simulation
        
        g_DisplayUpdateInProgress = false;
    }
}

/**
 * @brief RACE CONDITION SCENARIO 2: Concurrent Buffer Read/Write
 */
void IC_DisplayManager_UpdateRPM(uint16 rpm)
{
    /* PROBLEM: Same shared resource, different access pattern */
    while (g_BufferLock); // Busy wait - can cause deadlock
    
    g_BufferLock = true;
    
    /* Another thread might have changed the buffer state */
    if (g_DisplayBuffer.rpmValid) // <- Race condition with reader
    {
        g_DisplayBuffer.rpmValue = rpm;
        /* Missing unlock in certain conditions - DEADLOCK RISK */
        if (rpm > MAX_RPM_VALUE)
        {
            // ERROR: Missing g_BufferLock = false; 
            return; // DEADLOCK - lock never released!
        }
    }
    
    g_BufferLock = false;
}

/**
 * @brief RACE CONDITION SCENARIO 3: Display Refresh Function
 * Called from high-priority interrupt context
 */
void IC_DisplayManager_RefreshDisplay(void)
{
    DisplayBuffer_t localBuffer;
    
    /* PROBLEM: Non-atomic copy of shared data structure */
    if (!g_BufferLock) // <- Race condition check
    {
        /* Copying without synchronization - data can change mid-copy */
        memcpy(&localBuffer, &g_DisplayBuffer, sizeof(DisplayBuffer_t));
        
        /* Display hardware update */
        Display_UpdateSpeed(localBuffer.speedValue);
        Display_UpdateRPM(localBuffer.rpmValue);
        Display_UpdateFuelLevel(localBuffer.fuelLevel);
    }
    else
    {
        /* PROBLEM: No fallback strategy - display freezes */
        // IC becomes "dead" - no display updates
    }
}

/**
 * @brief RACE CONDITION SCENARIO 4: Interrupt vs Task Context
 * This function is called from both task and interrupt contexts
 */
void IC_DisplayManager_HandleCANMessage(uint32 canId, uint8* data)
{
    switch (canId)
    {
        case CAN_ID_SPEED:
            /* CRITICAL: Interrupt can preempt task here */
            IC_DisplayManager_UpdateSpeed(*(float*)data);
            break;
            
        case CAN_ID_RPM:
            /* Same shared resource accessed from different contexts */
            IC_DisplayManager_UpdateRPM(*(uint16*)data);
            break;
            
        default:
            break;
    }
}

/**
 * @brief RACE CONDITION SCENARIO 5: Priority Inversion
 * Low priority task holds lock, high priority task needs it
 */
void IC_DisplayManager_LowPriorityTask(void)
{
    /* Low priority task acquires critical resource */
    while (g_BufferLock); // Wait for lock
    g_BufferLock = true;
    
    /* Simulate long processing that can be preempted */
    IC_ProcessComplexCalculations(); // Takes 10ms
    
    /* High priority interrupt might be blocked waiting for this */
    g_DisplayBuffer.diagnosticData = GetDiagnosticInfo();
    
    g_BufferLock = false;
}

/**
 * @brief PROBLEMATIC: No proper error recovery mechanism
 * If any race condition corrupts the system state, IC becomes dead
 */
void IC_DisplayManager_ErrorRecovery(void)
{
    /* INSUFFICIENT: Simple reset doesn't handle race conditions */
    memset(&g_DisplayBuffer, 0, sizeof(DisplayBuffer_t));
    g_BufferLock = false;
    g_DisplayUpdateInProgress = false;
    
    /* MISSING: Proper synchronization reset */
    /* MISSING: Task state cleanup */
    /* MISSING: Hardware state verification */
}

/**
 * @brief Demonstrates the race condition that causes IC to become dead
 */
void IC_DisplayManager_SimulateRaceCondition(void)
{
    /*
     * SCENARIO: Two tasks running concurrently
     * Task A: Updates speed (calls IC_DisplayManager_UpdateSpeed)
     * Task B: Updates RPM (calls IC_DisplayManager_UpdateRPM) 
     * Interrupt: Refreshes display (calls IC_DisplayManager_RefreshDisplay)
     * 
     * RACE CONDITION SEQUENCE:
     * 1. Task A starts updating speed, sets g_DisplayUpdateInProgress = true
     * 2. Interrupt occurs, Task A preempted
     * 3. Task B tries to update RPM, gets stuck in while loop
     * 4. Interrupt handler tries to refresh display, sees lock, skips update
     * 5. Task A resumes but buffer state is inconsistent
     * 6. Display shows corrupted data or freezes - IC appears "dead"
     */
}