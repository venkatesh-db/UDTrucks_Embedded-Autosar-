/**
 * @file IC_DisplayManager.h
 * @brief Header file for Instrument Cluster Display Manager
 * @version 1.0
 * @date 2025-11-07
 */

#ifndef IC_DISPLAYMANAGER_H
#define IC_DISPLAYMANAGER_H

#include "Std_Types.h"

/* Maximum values */
#define MAX_SPEED_VALUE     300.0f
#define MAX_RPM_VALUE       8000u
#define MAX_FUEL_LEVEL      100.0f

/* CAN Message IDs */
#define CAN_ID_SPEED        0x123u
#define CAN_ID_RPM          0x124u
#define CAN_ID_FUEL         0x125u

/**
 * @brief Display Buffer Structure
 * Shared data structure that can be accessed by multiple threads
 */
typedef struct
{
    float speedValue;           /* Current speed in km/h */
    uint16 rpmValue;           /* Current RPM */
    float fuelLevel;           /* Fuel level percentage */
    bool speedValid;           /* Speed data validity flag */
    bool rpmValid;             /* RPM data validity flag */
    bool fuelValid;            /* Fuel data validity flag */
    uint32 timestamp;          /* Last update timestamp */
    uint8 diagnosticData;      /* Diagnostic information */
} DisplayBuffer_t;

/* Function prototypes */
void IC_DisplayManager_UpdateSpeed(float speed);
void IC_DisplayManager_UpdateRPM(uint16 rpm);
void IC_DisplayManager_RefreshDisplay(void);
void IC_DisplayManager_HandleCANMessage(uint32 canId, uint8* data);
void IC_DisplayManager_LowPriorityTask(void);
void IC_DisplayManager_ErrorRecovery(void);
void IC_DisplayManager_SimulateRaceCondition(void);

/* External functions */
extern void Display_UpdateSpeed(float speed);
extern void Display_UpdateRPM(uint16 rpm);
extern void Display_UpdateFuelLevel(float fuel);
extern void IC_ProcessComplexCalculations(void);
extern uint8 GetDiagnosticInfo(void);

#endif /* IC_DISPLAYMANAGER_H */