/**
 * @file IC_DisplayManager_Fixed.c
 * @brief CORRECTED Version - Race Condition Solutions for IC
 * @version 2.0
 * @date 2025-11-07
 * 
 * This file demonstrates proper AUTOSAR-compliant solutions to prevent
 * race conditions that cause Instrument Cluster dead state
 */

#include "IC_DisplayManager_Fixed.h"
#include "Rte_IC_DisplayManager.h"
#include "Os.h" /* AUTOSAR OS API */
#include <string.h>

/* Protected shared display buffer with proper synchronization */
static DisplayBuffer_t g_DisplayBuffer;
static ResourceType DisplayBufferMutex; /* AUTOSAR OS Resource */
static volatile uint32 g_UpdateCounter = 0;

/* Critical section protection using AUTOSAR OS */
static volatile boolean g_CriticalSectionActive = FALSE;

/**
 * @brief SOLUTION 1: Atomic Operations with AUTOSAR OS Resources
 */
Std_ReturnType IC_DisplayManager_UpdateSpeed_Fixed(float speed)
{
    StatusType osStatus;
    Std_ReturnType retVal = E_NOT_OK;
    
    /* SOLUTION: Use AUTOSAR OS Resource for mutual exclusion */
    osStatus = GetResource(DisplayBufferMutex);
    if (osStatus == E_OK)
    {
        /* Critical section - atomic update */
        SuspendAllInterrupts(); /* Disable interrupts for short atomic operation */
        
        g_DisplayBuffer.speedValue = speed;
        g_DisplayBuffer.speedValid = (speed >= 0.0f && speed <= MAX_SPEED_VALUE);
        g_DisplayBuffer.timestamp = GetSystemTime();
        g_UpdateCounter++;
        
        ResumeAllInterrupts(); /* Re-enable interrupts */
        
        /* Release the resource */
        ReleaseResource(DisplayBufferMutex);
        retVal = E_OK;
    }
    
    return retVal;
}

/**
 * @brief SOLUTION 2: Proper Resource Management with Timeout
 */
Std_ReturnType IC_DisplayManager_UpdateRPM_Fixed(uint16 rpm)
{
    StatusType osStatus;
    Std_ReturnType retVal = E_NOT_OK;
    TickType timeout = 10; /* 10ms timeout */
    
    /* SOLUTION: Resource acquisition with timeout */
    osStatus = GetResource(DisplayBufferMutex);
    if (osStatus == E_OK)
    {
        /* Validate input within critical section */
        if (rpm <= MAX_RPM_VALUE)
        {
            SuspendAllInterrupts();
            
            g_DisplayBuffer.rpmValue = rpm;
            g_DisplayBuffer.rpmValid = TRUE;
            g_DisplayBuffer.timestamp = GetSystemTime();
            
            ResumeAllInterrupts();
            retVal = E_OK;
        }
        
        /* CRITICAL: Always release resource */
        ReleaseResource(DisplayBufferMutex);
    }
    else
    {
        /* Handle resource acquisition failure */
        IC_DisplayManager_HandleResourceError();
    }
    
    return retVal;
}

/**
 * @brief SOLUTION 3: Safe Display Refresh with Double Buffering
 */
void IC_DisplayManager_RefreshDisplay_Fixed(void)
{
    DisplayBuffer_t localBuffer;
    StatusType osStatus;
    boolean dataValid = FALSE;
    
    /* SOLUTION: Try to acquire resource with non-blocking call */
    osStatus = GetResource(DisplayBufferMutex);
    if (osStatus == E_OK)
    {
        /* Quick atomic copy to minimize critical section */
        SuspendAllInterrupts();
        memcpy(&localBuffer, &g_DisplayBuffer, sizeof(DisplayBuffer_t));
        dataValid = TRUE;
        ResumeAllInterrupts();
        
        ReleaseResource(DisplayBufferMutex);
    }
    
    /* Update display outside critical section */
    if (dataValid)
    {
        /* Validate data integrity before display update */
        if (IC_ValidateDisplayData(&localBuffer))
        {
            Display_UpdateSpeed(localBuffer.speedValue);
            Display_UpdateRPM(localBuffer.rpmValue);
            Display_UpdateFuelLevel(localBuffer.fuelLevel);
        }
        else
        {
            /* Display safe fallback values */
            IC_DisplaySafeMode();
        }
    }
    else
    {
        /* Resource busy - use cached values or safe mode */
        IC_DisplayCachedValues();
    }
}

/**
 * @brief SOLUTION 4: Interrupt-Safe CAN Message Handling
 */
void IC_DisplayManager_HandleCANMessage_Fixed(uint32 canId, const uint8* data)
{
    /* SOLUTION: Defer processing to task context if called from ISR */
    if (IC_IsInterruptContext())
    {
        /* Queue message for task-level processing */
        IC_QueueCANMessage(canId, data);
        return;
    }
    
    /* Task context processing with proper synchronization */
    switch (canId)
    {
        case CAN_ID_SPEED:
            if (data != NULL)
            {
                float speed = *(const float*)data;
                IC_DisplayManager_UpdateSpeed_Fixed(speed);
            }
            break;
            
        case CAN_ID_RPM:
            if (data != NULL)
            {
                uint16 rpm = *(const uint16*)data;
                IC_DisplayManager_UpdateRPM_Fixed(rpm);
            }
            break;
            
        default:
            /* Handle unknown CAN ID */
            break;
    }
}

/**
 * @brief SOLUTION 5: Priority Inheritance to Prevent Priority Inversion
 */
void IC_DisplayManager_HighPriorityTask_Fixed(void)
{
    StatusType osStatus;
    
    /* SOLUTION: Use priority ceiling protocol */
    osStatus = GetResource(DisplayBufferMutex); /* This raises priority */
    if (osStatus == E_OK)
    {
        /* Critical processing with elevated priority */
        SuspendAllInterrupts();
        
        /* Quick critical operations */
        g_DisplayBuffer.diagnosticData = GetDiagnosticInfo();
        g_DisplayBuffer.timestamp = GetSystemTime();
        
        ResumeAllInterrupts();
        
        /* Always release resource to restore original priority */
        ReleaseResource(DisplayBufferMutex);
    }
}

/**
 * @brief SOLUTION 6: Comprehensive Error Recovery
 */
void IC_DisplayManager_ErrorRecovery_Fixed(void)
{
    /* Step 1: Force release all resources */
    ReleaseResource(DisplayBufferMutex); /* May return error if not held */
    
    /* Step 2: Reset all synchronization primitives */
    SuspendAllInterrupts();
    
    memset(&g_DisplayBuffer, 0, sizeof(DisplayBuffer_t));
    g_UpdateCounter = 0;
    g_CriticalSectionActive = FALSE;
    
    ResumeAllInterrupts();
    
    /* Step 3: Reinitialize hardware display */
    Display_HardwareReset();
    
    /* Step 4: Set safe default values */
    IC_SetSafeDefaultValues();
    
    /* Step 5: Restart display refresh task */
    IC_RestartDisplayTask();
}

/**
 * @brief Data validation to prevent corruption display
 */
boolean IC_ValidateDisplayData(const DisplayBuffer_t* buffer)
{
    if (buffer == NULL) return FALSE;
    
    /* Validate speed */
    if (buffer->speedValid && 
        (buffer->speedValue < 0.0f || buffer->speedValue > MAX_SPEED_VALUE))
    {
        return FALSE;
    }
    
    /* Validate RPM */
    if (buffer->rpmValid && buffer->rpmValue > MAX_RPM_VALUE)
    {
        return FALSE;
    }
    
    /* Validate fuel level */
    if (buffer->fuelValid && 
        (buffer->fuelLevel < 0.0f || buffer->fuelLevel > MAX_FUEL_LEVEL))
    {
        return FALSE;
    }
    
    return TRUE;
}

/**
 * @brief Initialize display manager with proper resource setup
 */
void IC_DisplayManager_Init_Fixed(void)
{
    /* Initialize AUTOSAR OS Resource */
    /* Note: Resource definition should be in OIL file */
    
    /* Initialize display buffer with safe values */
    SuspendAllInterrupts();
    
    memset(&g_DisplayBuffer, 0, sizeof(DisplayBuffer_t));
    g_DisplayBuffer.speedValid = FALSE;
    g_DisplayBuffer.rpmValid = FALSE;
    g_DisplayBuffer.fuelValid = FALSE;
    g_UpdateCounter = 0;
    
    ResumeAllInterrupts();
    
    /* Initialize display hardware */
    Display_HardwareInit();
    
    /* Set initial safe display */
    IC_DisplaySafeMode();
}

/* Helper functions for error handling */
static void IC_DisplayManager_HandleResourceError(void)
{
    /* Log error and attempt recovery */
    DET_ReportError(IC_MODULE_ID, IC_INSTANCE_ID, IC_UPDATE_RPM_API_ID, IC_E_RESOURCE_BUSY);
    
    /* Increment error counter for diagnostics */
    IC_IncrementErrorCounter(IC_ERROR_RESOURCE_TIMEOUT);
}

static void IC_DisplaySafeMode(void)
{
    /* Display predefined safe values */
    Display_UpdateSpeed(0.0f);
    Display_UpdateRPM(0u);
    Display_UpdateFuelLevel(0.0f);
    Display_ShowSafeModeIndicator();
}

static void IC_DisplayCachedValues(void)
{
    /* Use previously cached valid values */
    static DisplayBuffer_t lastValidBuffer = {0};
    
    if (IC_ValidateDisplayData(&lastValidBuffer))
    {
        Display_UpdateSpeed(lastValidBuffer.speedValue);
        Display_UpdateRPM(lastValidBuffer.rpmValue);
        Display_UpdateFuelLevel(lastValidBuffer.fuelLevel);
    }
    else
    {
        IC_DisplaySafeMode();
    }
}