/**
 * @file IC_DisplayManager_Fixed.h
 * @brief Header for corrected Display Manager implementation
 * @version 2.0
 * @date 2025-11-07
 */

#ifndef IC_DISPLAYMANAGER_FIXED_H
#define IC_DISPLAYMANAGER_FIXED_H

#include "Std_Types.h"
#include "Os.h"

/* Error codes for diagnostics */
#define IC_E_RESOURCE_BUSY      0x01u
#define IC_E_INVALID_DATA       0x02u
#define IC_E_TIMEOUT            0x03u

/* Module identification */
#define IC_MODULE_ID            0x100u
#define IC_INSTANCE_ID          0x00u
#define IC_UPDATE_RPM_API_ID    0x01u

/* Error types */
#define IC_ERROR_RESOURCE_TIMEOUT   0x01u

/* Maximum values */
#define MAX_SPEED_VALUE     300.0f
#define MAX_RPM_VALUE       8000u
#define MAX_FUEL_LEVEL      100.0f

/* CAN Message IDs */
#define CAN_ID_SPEED        0x123u
#define CAN_ID_RPM          0x124u
#define CAN_ID_FUEL         0x125u

/**
 * @brief Enhanced Display Buffer Structure with integrity checks
 */
typedef struct
{
    float speedValue;           /* Current speed in km/h */
    uint16 rpmValue;           /* Current RPM */
    float fuelLevel;           /* Fuel level percentage */
    boolean speedValid;        /* Speed data validity flag */
    boolean rpmValid;          /* RPM data validity flag */
    boolean fuelValid;         /* Fuel data validity flag */
    uint32 timestamp;          /* Last update timestamp */
    uint8 diagnosticData;      /* Diagnostic information */
    uint32 checksum;           /* Data integrity checksum */
} DisplayBuffer_t;

/* Fixed function prototypes */
Std_ReturnType IC_DisplayManager_UpdateSpeed_Fixed(float speed);
Std_ReturnType IC_DisplayManager_UpdateRPM_Fixed(uint16 rpm);
void IC_DisplayManager_RefreshDisplay_Fixed(void);
void IC_DisplayManager_HandleCANMessage_Fixed(uint32 canId, const uint8* data);
void IC_DisplayManager_HighPriorityTask_Fixed(void);
void IC_DisplayManager_ErrorRecovery_Fixed(void);
void IC_DisplayManager_Init_Fixed(void);

/* Validation and utility functions */
boolean IC_ValidateDisplayData(const DisplayBuffer_t* buffer);
uint32 GetSystemTime(void);

/* External functions */
extern void Display_UpdateSpeed(float speed);
extern void Display_UpdateRPM(uint16 rpm);
extern void Display_UpdateFuelLevel(float fuel);
extern void Display_HardwareReset(void);
extern void Display_HardwareInit(void);
extern void Display_ShowSafeModeIndicator(void);
extern uint8 GetDiagnosticInfo(void);
extern boolean IC_IsInterruptContext(void);
extern void IC_QueueCANMessage(uint32 canId, const uint8* data);
extern void IC_SetSafeDefaultValues(void);
extern void IC_RestartDisplayTask(void);
extern void IC_IncrementErrorCounter(uint8 errorType);
extern void DET_ReportError(uint16 moduleId, uint8 instanceId, uint8 apiId, uint8 errorId);

/* AUTOSAR OS Resource declaration */
DeclareResource(DisplayBufferMutex);

#endif /* IC_DISPLAYMANAGER_FIXED_H */