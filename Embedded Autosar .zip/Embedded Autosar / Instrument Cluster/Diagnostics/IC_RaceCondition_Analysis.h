/**
 * @file IC_RaceCondition_Analysis.h
 * @brief Header file for IC Race Condition Analysis Tool
 * @version 1.0
 * @date 2025-11-07
 */

#ifndef IC_RACECONDITION_ANALYSIS_H
#define IC_RACECONDITION_ANALYSIS_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

/* AUTOSAR type compatibility for demonstration */
typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uint8_t uint8;

/* Configuration constants */
#define MAX_RACE_EVENTS         1000
#define MAX_THREADS             32
#define MAX_RESOURCES           16
#define MAX_HELD_RESOURCES      8
#define MIN_SAFE_ACCESS_INTERVAL 10  /* microseconds */
#define REPORT_SEPARATOR        "=================================================="

/* Resource IDs for tracking */
#define RESOURCE_DISPLAY_BUFFER     1
#define RESOURCE_CAN_BUFFER         2
#define RESOURCE_DIAGNOSTIC_DATA    3
#define RESOURCE_SPEED_DATA         4
#define RESOURCE_RPM_DATA           5

/**
 * @brief Race condition event types
 */
typedef enum
{
    RACE_EVENT_RESOURCE_LOCK = 0,
    RACE_EVENT_RESOURCE_UNLOCK,
    RACE_EVENT_SHARED_ACCESS,
    RACE_EVENT_PRIORITY_WAIT,
    RACE_EVENT_INTERRUPT,
    RACE_EVENT_MAX
} RaceEventType_t;

/**
 * @brief Race condition types for classification
 */
typedef enum
{
    RACE_TYPE_DOUBLE_LOCK = 0,
    RACE_TYPE_CONCURRENT_ACCESS,
    RACE_TYPE_PRIORITY_INVERSION,
    RACE_TYPE_DEADLOCK_CYCLE,
    RACE_TYPE_RAPID_ACCESS,
    RACE_TYPE_MISSING_UNLOCK,
    RACE_TYPE_MAX
} RaceConditionType_t;

/**
 * @brief Race condition event log structure
 */
typedef struct
{
    uint32 timestamp;           /* High-resolution timestamp */
    RaceEventType_t eventType;  /* Type of race event */
    uint32 threadId;            /* Thread ID involved */
    uint32 resourceId;          /* Resource ID involved */
    char location[64];          /* Source code location */
    uint8 cpuUsage;            /* CPU usage at time of event */
    uint8 memoryUsage;         /* Memory usage at time of event */
} RaceConditionLog_t;

/**
 * @brief Thread information for deadlock detection
 */
typedef struct
{
    uint32 threadId;                    /* Thread identifier */
    uint8 priority;                     /* Thread priority */
    uint32 waitingForResource;          /* Resource ID thread is waiting for */
    uint32 heldResources[MAX_HELD_RESOURCES]; /* Resources currently held */
    uint32 lastActivityTime;            /* Last activity timestamp */
    bool isBlocked;                     /* Thread blocking status */
} ThreadInfo_t;

/**
 * @brief Resource information for contention analysis
 */
typedef struct
{
    uint32 resourceId;          /* Resource identifier */
    uint32 accessCount;         /* Number of current accessors */
    uint32 lastAccessTime;      /* Last access timestamp */
    uint32 holdingThreadId;     /* Thread currently holding resource */
    uint32 totalContentions;    /* Total contention count */
    uint32 maxWaitTime;         /* Maximum wait time observed */
} ResourceInfo_t;

/* Function prototypes */
void IC_RaceAnalysis_Init(void);
void IC_RaceAnalysis_LogEvent(RaceEventType_t eventType, uint32 threadId, 
                              uint32 resourceId, const char* location);
void IC_RaceAnalysis_GenerateReport(void);
void IC_RaceAnalysis_SimulateScenarios(void);
int IC_RaceCondition_AnalysisMain(void);

/* Internal analysis functions */
static void IC_RaceAnalysis_DetectPattern(const RaceConditionLog_t* currentEvent);
static void IC_CheckForMissingUnlock(uint32 threadId, uint32 resourceId);
static void IC_CheckForConcurrentAccess(uint32 resourceId);
static void IC_CheckForPriorityInversion(uint32 waitingThreadId);
static void IC_CheckForDeadlockCycle(void);

/* Utility functions */
static ThreadInfo_t* IC_FindThread(uint32 threadId);
static ResourceInfo_t* IC_FindResource(uint32 resourceId);
static ThreadInfo_t* IC_FindResourceHolder(uint32 resourceId);
static int IC_GetThreadIndex(uint32 threadId);
static bool IC_DetectCycleInGraph(bool waitGraph[][MAX_THREADS]);
static void IC_RecordResourceHeld(uint32 threadId, uint32 resourceId);
static void IC_CheckDeadlockPotential(uint32 threadId, uint32 newResource, uint32 heldResource);

/* Reporting functions */
static void IC_ReportRaceCondition(RaceConditionType_t type, uint32 threadId, 
                                 uint32 resourceId, const char* description);
static void IC_GenerateDeadlockReport(void);
static void IC_PrintEventSummary(void);
static void IC_PrintCriticalRaceConditions(void);
static void IC_PrintResourceContentionAnalysis(void);
static void IC_PrintDeadlockAnalysis(void);
static void IC_PrintRecommendations(void);
static bool IC_IsCriticalRacePattern(const RaceConditionLog_t* event);

/* Simulation functions */
static void IC_SimulateDisplayBufferRace(void);
static void IC_SimulateCANMessageRace(void);
static void IC_SimulatePriorityInversion(void);
static void IC_SimulateDeadlock(void);

/* External helper functions (to be implemented) */
extern uint32 GetHighResolutionTimer(void);
extern uint8 GetCurrentCPUUsage(void);
extern uint8 GetCurrentMemoryUsage(void);
extern uint32 GetAnalysisDuration(void);

#endif /* IC_RACECONDITION_ANALYSIS_H */