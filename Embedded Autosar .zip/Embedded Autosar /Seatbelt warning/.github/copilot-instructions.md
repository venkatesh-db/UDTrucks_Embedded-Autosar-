# Copilot Instructions - AUTOSAR Seatbelt Warning System

## Project Overview
This is an embedded automotive project implementing a seatbelt warning system following AUTOSAR (AUTomotive Open System ARchitecture) standards. The system monitors seatbelt status and provides appropriate warnings to the driver.

## Architecture & Key Concepts

### AUTOSAR Software Components (SWCs)
- **Application Layer**: Seatbelt warning logic and user interface
- **Runtime Environment (RTE)**: Inter-component communication layer
- **Basic Software (BSW)**: Hardware abstraction and system services
- **Configuration**: ARXML files define component interfaces and system configuration

### Critical Files & Directories
- `src/application/`: Application software components
- `src/rte/`: Generated RTE code from AUTOSAR tools
- `src/bsw/`: Basic software modules (drivers, OS, communication)
- `config/`: AUTOSAR configuration files (.arxml)
- `tests/`: Unit tests and integration tests

## Development Patterns

### Signal Flow Architecture
```
Seatbelt Sensor → Input Processing → Warning Logic → Output (Display/Sound)
```
- Use AUTOSAR sender-receiver interfaces for asynchronous data
- Implement client-server interfaces for service calls
- Follow AUTOSAR naming conventions (e.g., `Rte_Read_`, `Rte_Write_`)

### Code Organization
- Each SWC has separate `.c/.h` files in dedicated directories
- RTE-generated code goes in `src/rte/` (don't modify manually)
- Configuration-dependent code uses preprocessor macros
- Safety-critical functions require MISRA C compliance

### Memory & Timing Constraints
- Static memory allocation preferred (no malloc/free)
- Fixed-point arithmetic over floating-point when possible
- Cyclic tasks run on 10ms/100ms schedules (configurable)
- Interrupt service routines kept minimal

## Testing & Validation

### Unit Testing
- Use framework compatible with embedded targets (Unity, Google Test)
- Mock RTE interfaces for isolated component testing
- Test both normal and fault conditions

### Integration Testing
- HIL (Hardware-in-Loop) testing with actual sensors
- CAN bus simulation for vehicle network testing
- Safety case validation for functional safety requirements

## Build & Configuration

### AUTOSAR Toolchain
- Configuration tools generate RTE and BSW code
- Build system handles multiple ECU configurations
- Flash/debug through JTAG or bootloader

### Safety Standards
- Follow ISO 26262 for functional safety
- ASIL (Automotive Safety Integrity Level) requirements
- Traceability between requirements and implementation

## Common Pitfalls
- Don't modify RTE-generated files directly
- Ensure proper error handling for CAN timeouts
- Validate seatbelt sensor debouncing logic
- Consider ignition state for warning activation timing

## Key Dependencies
- AUTOSAR Classic Platform specification
- Vehicle-specific CAN database (.dbc files)
- Hardware abstraction layer for target ECU
- Calibration parameters for warning thresholds

## Safety Case Quick Reference (ASIL-B – False Trigger)
- Scenario: False seatbelt warning when belt is latched or seat is unoccupied; limit nuisance/distraction.
- Gating: Ignition=ON, Speed ≥ 10 km/h, 2.0 s door-close grace, occupancy=Occupied.
- Debounce: Latch on-delay 50 ms, unlatch on-delay 500 ms; occupancy debounce ≥ 300 ms (calibrated).
- Timing: 10 ms periodic runnables for inputs and logic; end-to-end ≤ 100 ms typical (≤ 200 ms worst-case).
- Diagnostics: Stale/invalid inputs inhibit warnings and raise DTCs; use alive counters and CRC for CAN signals.
- AUTOSAR SWCs:
	- `Seatbelt_Sensor_IF` (debounce + validity)
	- `Occupancy_Sensor_IF` (classification + validity)
	- `VehicleState_IF` (ignition/speed/door)
	- `SeatbeltWarning_Logic` (state machine + HMI request)
- Full details: see `docs/safety/seatbelt_false_trigger_case.md`.