#ifndef CRC_H
#define CRC_H
#include <stdint.h>
uint16_t Crc16_Calc(const void* data, uint32_t len);
#endif // CRC_H
