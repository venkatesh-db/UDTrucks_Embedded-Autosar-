/*******************************************************************************
 * File: Std_Types.h
 * Description: AUTOSAR Standard Types Definition
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Defines standard AUTOSAR data types and return values
 *******************************************************************************/

#ifndef STD_TYPES_H
#define STD_TYPES_H

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "Platform_Types.h"
#include "Compiler.h"

/*******************************************************************************
 * STANDARD TYPES
 *******************************************************************************/
typedef uint8 Std_ReturnType;

#define E_OK        ((Std_ReturnType)0x00U)
#define E_NOT_OK    ((Std_ReturnType)0x01U)

#define STD_HIGH    0x01U
#define STD_LOW     0x00U

#define STD_ACTIVE  0x01U
#define STD_IDLE    0x00U

#define STD_ON      0x01U
#define STD_OFF     0x00U

/*******************************************************************************
 * VERSION INFO TYPE
 *******************************************************************************/
typedef struct {
    uint16 vendorID;
    uint16 moduleID;
    uint8 sw_major_version;
    uint8 sw_minor_version;
    uint8 sw_patch_version;
} Std_VersionInfoType;

/*******************************************************************************
 * TRANSFORMATION TYPES
 *******************************************************************************/
typedef enum {
    STD_TRANSFORMER_UNSPECIFIED = 0x00,
    STD_TRANSFORMER_SERIALIZER = 0x01,
    STD_TRANSFORMER_SAFETY = 0x02,
    STD_TRANSFORMER_SECURITY = 0x03,
    STD_TRANSFORMER_CUSTOM = 0xFF
} Std_TransformerClass;

typedef uint8 Std_TransformerType;

typedef struct {
    Std_TransformerClass transformerClass;
    Std_TransformerType transformerType;
} Std_TransformerError;

#endif /* STD_TYPES_H */