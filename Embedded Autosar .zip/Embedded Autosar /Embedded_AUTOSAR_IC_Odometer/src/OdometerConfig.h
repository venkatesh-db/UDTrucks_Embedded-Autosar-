/*******************************************************************************
 * File: OdometerConfig.h
 * Description: Configuration constants for AUTOSAR IC Odometer Manager
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Contains all configuration constants and module IDs
 *******************************************************************************/

#ifndef ODOMETER_CONFIG_H
#define ODOMETER_CONFIG_H

/*******************************************************************************
 * MODULE IDENTIFICATION
 *******************************************************************************/
#define ODOMETER_MODULE_ID           100U
#define ODOMETER_INSTANCE_ID         0U
#define ODOMETER_VENDOR_ID           1U
#define ODOMETER_AR_RELEASE_MAJOR    4U
#define ODOMETER_AR_RELEASE_MINOR    3U
#define ODOMETER_AR_RELEASE_PATCH    0U
#define ODOMETER_SW_MAJOR_VERSION    1U
#define ODOMETER_SW_MINOR_VERSION    0U
#define ODOMETER_SW_PATCH_VERSION    0U

/*******************************************************************************
 * CAN HANDLER MODULE IDENTIFICATION
 *******************************************************************************/
#define CAN_HANDLER_MODULE_ID        101U
#define CAN_HANDLER_INSTANCE_ID      0U

/*******************************************************************************
 * API SERVICE IDS
 *******************************************************************************/
#define ODOMETER_API_INIT            0x00U
#define ODOMETER_API_DEINIT          0x01U
#define ODOMETER_API_UPDATE_VALUE    0x02U
#define ODOMETER_API_GET_VALUE       0x03U
#define ODOMETER_API_SAVE_TO_NVM     0x04U
#define ODOMETER_API_LOAD_FROM_NVM   0x05U
#define ODOMETER_API_RESET           0x06U

#define CAN_HANDLER_API_INIT                    0x10U
#define CAN_HANDLER_API_RX_INDICATION          0x11U
#define CAN_HANDLER_API_BUS_OFF_NOTIFICATION   0x12U
#define CAN_HANDLER_API_ERROR_NOTIFICATION     0x13U

/*******************************************************************************
 * ERROR CODES
 *******************************************************************************/
#define ODOMETER_E_UNINIT               0x01U
#define ODOMETER_E_PARAM_POINTER        0x02U
#define ODOMETER_E_PARAM_VALUE          0x03U
#define ODOMETER_E_NVM_READ_FAILED      0x04U
#define ODOMETER_E_NVM_WRITE_FAILED     0x05U
#define ODOMETER_E_VALUE_JUMP_DETECTED  0x06U
#define ODOMETER_E_CAN_TIMEOUT          0x07U

#define CAN_HANDLER_E_UNINIT            0x10U
#define CAN_HANDLER_E_PARAM_POINTER     0x11U
#define CAN_HANDLER_E_INVALID_PDU_ID    0x12U
#define CAN_HANDLER_E_BUS_OFF           0x13U
#define CAN_HANDLER_E_CAN_ERROR         0x14U

/*******************************************************************************
 * CONFIGURATION PARAMETERS
 *******************************************************************************/
#define ODOMETER_DEV_ERROR_DETECT       STD_ON
#define ODOMETER_VERSION_INFO_API       STD_ON
#define ODOMETER_NVM_SUPPORT           STD_ON
#define ODOMETER_DIAGNOSTIC_SUPPORT    STD_ON

#endif /* ODOMETER_CONFIG_H */