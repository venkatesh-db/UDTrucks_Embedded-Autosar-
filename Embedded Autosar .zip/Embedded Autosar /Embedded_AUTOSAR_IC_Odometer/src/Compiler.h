/*******************************************************************************
 * File: Compiler.h
 * Description: AUTOSAR Compiler Abstraction
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Provides compiler-specific definitions and abstractions
 *******************************************************************************/

#ifndef COMPILER_H
#define COMPILER_H

/*******************************************************************************
 * COMPILER IDENTIFICATION
 *******************************************************************************/
#define COMPILER_VENDOR_ID          1U

/*******************************************************************************
 * MEMORY AND POINTER CLASS DEFINITIONS
 *******************************************************************************/
#define AUTOMATIC
#define STATIC      static
#define NULL_PTR    ((void *)0)

/*******************************************************************************
 * FUNCTION MODIFIERS
 *******************************************************************************/
#define FUNC(rettype, memclass)         rettype
#define P2VAR(ptrtype, memclass, ptrclass)    ptrtype *
#define P2CONST(ptrtype, memclass, ptrclass)  const ptrtype *
#define CONSTP2VAR(ptrtype, memclass, ptrclass)   ptrtype * const
#define CONSTP2CONST(ptrtype, memclass, ptrclass) const ptrtype * const
#define P2FUNC(rettype, ptrclass, fctname)    rettype (*fctname)
#define CONST(consttype, memclass)      const consttype
#define VAR(vartype, memclass)          vartype

/*******************************************************************************
 * INLINE FUNCTIONS
 *******************************************************************************/
#define INLINE      inline
#define LOCAL_INLINE    static inline

#endif /* COMPILER_H */