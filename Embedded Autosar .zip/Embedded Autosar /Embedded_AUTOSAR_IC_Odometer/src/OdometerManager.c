/*******************************************************************************
 * File: OdometerManager.c
 * Description: AUTOSAR IC Odometer Manager Implementation
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Implements odometer value handling with CAN communication loss protection
 *          Prevents odometer value jumps during CAN bus failures
 *******************************************************************************/

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "OdometerManager.h"
#include "OdometerConfig.h"  // CRITICAL: Missing config constants
#include "Os.h"
#include "Det.h"

/*******************************************************************************
 * LOCAL VARIABLES
 *******************************************************************************/
static OdometerManager_t g_OdometerManager;
static uint32 g_SystemTick = 0;

/*******************************************************************************
 * LOCAL FUNCTION PROTOTYPES
 *******************************************************************************/
static uint16 OdometerManager_FilterSpeed(uint16 newSpeed);
static uint32 OdometerManager_CalculateExpectedOdometer(uint32 currentOdometer, 
                                                       uint16 speed, 
                                                       uint32 timeElapsed);
static void OdometerManager_UpdateState(void);
static boolean OdometerManager_IsValueReasonable(uint32 newValue, uint32 expectedValue);

/*******************************************************************************
 * FUNCTION IMPLEMENTATIONS
 *******************************************************************************/

/**
 * @brief Initialize the Odometer Manager
 */
Std_ReturnType OdometerManager_Init(void)
{
    Std_ReturnType retVal = E_OK;
    uint8 i;
    
    /* Initialize the odometer manager structure */
    g_OdometerManager.currentOdometerValue = 0;
    g_OdometerManager.lastValidOdometerValue = 0;
    g_OdometerManager.nvmBackupValue = 0;
    g_OdometerManager.currentSpeed = 0;
    g_OdometerManager.lastValidSpeed = 0;
    g_OdometerManager.lastUpdateTime = 0;
    g_OdometerManager.canTimeoutCounter = 0;
    g_OdometerManager.state = ODOMETER_STATE_INIT;
    g_OdometerManager.canStatus = CAN_COMM_NO_COMMUNICATION;
    g_OdometerManager.isInitialized = FALSE;
    g_OdometerManager.dataValid = FALSE;
    g_OdometerManager.filterIndex = 0;
    
    /* Initialize speed filter buffer */
    for(i = 0; i < ODOMETER_SPEED_FILTER_SAMPLES; i++)
    {
        g_OdometerManager.speedFilterBuffer[i] = 0;
    }
    
    /* Load odometer value from NVM */
    retVal = OdometerManager_LoadFromNvm();
    
    if(retVal == E_OK)
    {
        g_OdometerManager.currentOdometerValue = g_OdometerManager.nvmBackupValue;
        g_OdometerManager.lastValidOdometerValue = g_OdometerManager.nvmBackupValue;
        g_OdometerManager.state = ODOMETER_STATE_NORMAL_OPERATION;
        g_OdometerManager.isInitialized = TRUE;
        g_OdometerManager.dataValid = TRUE;  /* FIXED: Set data valid after successful init */
    }
    else
    {
        g_OdometerManager.state = ODOMETER_STATE_ERROR;
        /* Report error to DET */
        Det_ReportError(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                       ODOMETER_API_INIT, ODOMETER_E_NVM_READ_FAILED);
    }
    
    return retVal;
}

/**
 * @brief Main function to be called cyclically (typically every 10ms)
 */
void OdometerManager_MainFunction(void)
{
    g_SystemTick++;
    
    if(!g_OdometerManager.isInitialized)
    {
        return;
    }
    
    /* Update odometer state based on CAN communication */
    OdometerManager_UpdateState();
    
    /* Check for CAN timeout */
    if((g_SystemTick - g_OdometerManager.lastUpdateTime) > ODOMETER_CAN_TIMEOUT_MS)
    {
        OdometerManager_HandleCanTimeout();
    }
    
    /* Periodic NVM save (every 5 seconds with valid data) */
    if(((g_SystemTick % 5000) == 0) && g_OdometerManager.dataValid)
    {
        OdometerManager_SaveToNvm();
    }
}

/**
 * @brief Update odometer value from CAN message
 */
Std_ReturnType OdometerManager_UpdateValue(uint32 odometerValue, uint16 speedValue)
{
    Std_ReturnType retVal = E_NOT_OK;
    uint16 filteredSpeed;
    
    if(!g_OdometerManager.isInitialized)
    {
        return E_NOT_OK;
    }
    
    /* Filter the speed value */
    filteredSpeed = OdometerManager_FilterSpeed(speedValue);
    
    /* Validate the new odometer value */
    if(OdometerManager_ValidateOdometerValue(odometerValue, filteredSpeed))
    {
        /* Update values */
        g_OdometerManager.lastValidOdometerValue = g_OdometerManager.currentOdometerValue;
        g_OdometerManager.currentOdometerValue = odometerValue;
        g_OdometerManager.lastValidSpeed = g_OdometerManager.currentSpeed;
        g_OdometerManager.currentSpeed = filteredSpeed;
        g_OdometerManager.lastUpdateTime = g_SystemTick;
        g_OdometerManager.canTimeoutCounter = 0;
        g_OdometerManager.dataValid = TRUE;
        g_OdometerManager.canStatus = CAN_COMM_OK;
        
        /* Update state if recovering from timeout */
        if(g_OdometerManager.state == ODOMETER_STATE_CAN_TIMEOUT ||
           g_OdometerManager.state == ODOMETER_STATE_COMMUNICATION_LOST)
        {
            OdometerManager_HandleCanRecovery();
        }
        
        retVal = E_OK;
    }
    else
    {
        /* Reject the value - potential jump detected */
        Det_ReportError(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                       ODOMETER_API_UPDATE_VALUE, ODOMETER_E_VALUE_JUMP_DETECTED);
    }
    
    return retVal;
}

/**
 * @brief Get current odometer value
 */
Std_ReturnType OdometerManager_GetValue(uint32* odometerValue)
{
    if(odometerValue == NULL_PTR)
    {
        return E_NOT_OK;
    }
    
    if(!g_OdometerManager.isInitialized || !g_OdometerManager.dataValid)
    {
        return E_NOT_OK;
    }
    
    *odometerValue = g_OdometerManager.currentOdometerValue;
    return E_OK;
}

/**
 * @brief Handle CAN communication timeout
 */
void OdometerManager_HandleCanTimeout(void)
{
    g_OdometerManager.canTimeoutCounter++;
    
    if(g_OdometerManager.canTimeoutCounter >= 3) /* 3 consecutive timeouts */
    {
        g_OdometerManager.state = ODOMETER_STATE_COMMUNICATION_LOST;
        g_OdometerManager.canStatus = CAN_COMM_TIMEOUT;
        
        /* Freeze the odometer value - don't increment during communication loss */
        g_OdometerManager.dataValid = FALSE;
        
        /* Save current value to NVM as backup */
        OdometerManager_SaveToNvm();
    }
    else
    {
        g_OdometerManager.state = ODOMETER_STATE_CAN_TIMEOUT;
    }
}

/**
 * @brief Handle CAN communication recovery
 */
void OdometerManager_HandleCanRecovery(void)
{
    g_OdometerManager.state = ODOMETER_STATE_NORMAL_OPERATION;
    g_OdometerManager.canStatus = CAN_COMM_OK;
    g_OdometerManager.canTimeoutCounter = 0;
}

/**
 * @brief Validate odometer value to prevent jumps
 */
boolean OdometerManager_ValidateOdometerValue(uint32 newValue, uint16 currentSpeed)
{
    uint32 expectedValue;
    uint32 timeElapsed;
    uint32 maxAllowedDifference;
    
    /* If this is the first valid value, accept it */
    if(!g_OdometerManager.dataValid)
    {
        return TRUE;
    }
    
    /* Calculate time elapsed since last update */
    timeElapsed = g_SystemTick - g_OdometerManager.lastUpdateTime;
    
    /* Calculate expected odometer value based on last speed */
    expectedValue = OdometerManager_CalculateExpectedOdometer(
        g_OdometerManager.currentOdometerValue,
        g_OdometerManager.currentSpeed,
        timeElapsed);
    
    /* Calculate maximum allowed difference based on current speed */
    /* Allow for 10% deviation plus a fixed margin */
    maxAllowedDifference = (currentSpeed * timeElapsed * 11) / (10 * 3600); /* km to meters conversion */
    maxAllowedDifference += 50; /* Fixed 50m margin */
    
    /* Check if the new value is reasonable */
    return OdometerManager_IsValueReasonable(newValue, expectedValue);
}

/**
 * @brief Save odometer value to NVM
 */
Std_ReturnType OdometerManager_SaveToNvm(void)
{
    Std_ReturnType retVal;
    
    g_OdometerManager.nvmBackupValue = g_OdometerManager.currentOdometerValue;
    
    retVal = NvM_WriteBlock(ODOMETER_NVM_BLOCK_ID, &g_OdometerManager.nvmBackupValue);
    
    if(retVal != E_OK)
    {
        Det_ReportError(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                       ODOMETER_API_SAVE_TO_NVM, ODOMETER_E_NVM_WRITE_FAILED);
    }
    
    return retVal;
}

/**
 * @brief Load odometer value from NVM
 */
Std_ReturnType OdometerManager_LoadFromNvm(void)
{
    Std_ReturnType retVal;
    
    retVal = NvM_ReadBlock(ODOMETER_NVM_BLOCK_ID, &g_OdometerManager.nvmBackupValue);
    
    if(retVal != E_OK)
    {
        Det_ReportError(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                       ODOMETER_API_LOAD_FROM_NVM, ODOMETER_E_NVM_READ_FAILED);
    }
    
    return retVal;
}

/**
 * @brief Get current odometer state
 */
OdometerState_t OdometerManager_GetState(void)
{
    return g_OdometerManager.state;
}

/**
 * @brief Reset odometer manager
 */
void OdometerManager_Reset(void)
{
    /* Save current value before reset */
    if(g_OdometerManager.dataValid)
    {
        OdometerManager_SaveToNvm();
    }
    
    /* Reinitialize */
    OdometerManager_Init();
}

/*******************************************************************************
 * LOCAL FUNCTION IMPLEMENTATIONS
 *******************************************************************************/

/**
 * @brief Filter speed value using moving average
 */
static uint16 OdometerManager_FilterSpeed(uint16 newSpeed)
{
    uint32 sum = 0;
    uint8 i;
    
    /* Add new speed to filter buffer */
    g_OdometerManager.speedFilterBuffer[g_OdometerManager.filterIndex] = newSpeed;
    g_OdometerManager.filterIndex = (g_OdometerManager.filterIndex + 1) % ODOMETER_SPEED_FILTER_SAMPLES;
    
    /* Calculate moving average */
    for(i = 0; i < ODOMETER_SPEED_FILTER_SAMPLES; i++)
    {
        sum += g_OdometerManager.speedFilterBuffer[i];
    }
    
    return (uint16)(sum / ODOMETER_SPEED_FILTER_SAMPLES);
}

/**
 * @brief Calculate expected odometer value based on speed and time
 */
static uint32 OdometerManager_CalculateExpectedOdometer(uint32 currentOdometer, 
                                                       uint16 speed, 
                                                       uint32 timeElapsed)
{
    uint32 distanceTraveled;
    
    /* Convert speed (km/h * 10) to distance in meters */
    /* distance = speed * time / 3600 (convert hours to seconds) */
    distanceTraveled = (speed * timeElapsed) / (36000); /* speed is in km/h * 10, time in ms */
    
    return currentOdometer + distanceTraveled;
}

/**
 * @brief Update odometer state based on conditions
 */
static void OdometerManager_UpdateState(void)
{
    /* State machine logic could be expanded here */
    /* Currently handled in other functions */
}

/**
 * @brief Check if odometer value is reasonable
 */
static boolean OdometerManager_IsValueReasonable(uint32 newValue, uint32 expectedValue)
{
    uint32 difference;
    
    /* Calculate absolute difference */
    if(newValue > expectedValue)
    {
        difference = newValue - expectedValue;
    }
    else
    {
        difference = expectedValue - newValue;
    }
    
    /* Allow maximum 1km jump (considering possible CAN message loss) */
    return (difference <= 1000); /* 1000 meters = 1 km */
}