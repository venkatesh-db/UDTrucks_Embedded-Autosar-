/*******************************************************************************
 * File: CanCommHandler.c
 * Description: CAN Communication Handler Implementation
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Implements CAN communication handling for odometer data with robust
 *          error detection and timeout handling
 *******************************************************************************/

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "CanCommHandler.h"
#include "OdometerManager.h"
#include "Os.h"
#include "Det.h"

/*******************************************************************************
 * LOCAL VARIABLES
 *******************************************************************************/
static CanCommHandler_t g_CanCommHandler;
static uint32 g_SystemTickCan = 0;

/*******************************************************************************
 * LOCAL FUNCTION PROTOTYPES
 *******************************************************************************/
static void CanCommHandler_ProcessOdometerMessage(const PduInfoType* PduInfoPtr);
static void CanCommHandler_ProcessSpeedMessage(const PduInfoType* PduInfoPtr);
static uint32 CanCommHandler_ExtractOdometerValue(const uint8* data);
static uint16 CanCommHandler_ExtractSpeedValue(const uint8* data);
static boolean CanCommHandler_ValidateMessage(const PduInfoType* PduInfoPtr, uint8 expectedLength);
static void CanCommHandler_UpdateStateMachine(void);
static void CanCommHandler_HandleTimeout(void);

/*******************************************************************************
 * FUNCTION IMPLEMENTATIONS
 *******************************************************************************/

/**
 * @brief Initialize CAN Communication Handler
 */
Std_ReturnType CanCommHandler_Init(void)
{
    /* Initialize handler structure */
    g_CanCommHandler.state = CAN_HANDLER_STATE_INIT;
    g_CanCommHandler.lastMessageTime = 0;
    g_CanCommHandler.timeoutCounter = 0;
    g_CanCommHandler.errorCounter = 0;
    g_CanCommHandler.retryCounter = 0;
    g_CanCommHandler.isInitialized = FALSE;
    g_CanCommHandler.totalMessagesReceived = 0;
    g_CanCommHandler.totalMessageErrors = 0;
    
    /* Initialize last message structure */
    g_CanCommHandler.lastMessage.odometerValue = 0;
    g_CanCommHandler.lastMessage.speedValue = 0;
    g_CanCommHandler.lastMessage.timestamp = 0;
    g_CanCommHandler.lastMessage.isValid = FALSE;
    
    /* Set state to normal operation */
    g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
    g_CanCommHandler.isInitialized = TRUE;
    
    return E_OK;
}

/**
 * @brief Main function to be called cyclically
 */
void CanCommHandler_MainFunction(void)
{
    g_SystemTickCan++;
    
    if(!g_CanCommHandler.isInitialized)
    {
        return;
    }
    
    /* Update state machine */
    CanCommHandler_UpdateStateMachine();
    
    /* Check for timeout */
    if((g_SystemTickCan - g_CanCommHandler.lastMessageTime) > CAN_TIMEOUT_THRESHOLD)
    {
        CanCommHandler_HandleTimeout();
    }
    
    /* Handle bus-off recovery */
    if(g_CanCommHandler.state == CAN_HANDLER_STATE_BUS_OFF)
    {
        if((g_SystemTickCan - g_CanCommHandler.lastMessageTime) > CAN_BUS_OFF_RECOVERY_TIME)
        {
            /* Attempt recovery */
            g_CanCommHandler.retryCounter++;
            if(g_CanCommHandler.retryCounter < CAN_MAX_RETRY_COUNT)
            {
                g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
            }
            else
            {
                g_CanCommHandler.state = CAN_HANDLER_STATE_CRITICAL_ERROR;
            }
        }
    }
}

/**
 * @brief CAN message reception callback
 */
void CanCommHandler_RxIndication(PduIdType RxPduId, const PduInfoType* PduInfoPtr)
{
    if(!g_CanCommHandler.isInitialized || (PduInfoPtr == NULL_PTR))
    {
        g_CanCommHandler.totalMessageErrors++;
        return;
    }
    
    g_CanCommHandler.totalMessagesReceived++;
    g_CanCommHandler.lastMessageTime = g_SystemTickCan;
    
    switch(RxPduId)
    {
        case CAN_ODOMETER_MSG_ID:
            CanCommHandler_ProcessOdometerMessage(PduInfoPtr);
            break;
            
        case CAN_SPEED_MSG_ID:
            CanCommHandler_ProcessSpeedMessage(PduInfoPtr);
            break;
            
        default:
            /* Unknown message ID */
            g_CanCommHandler.totalMessageErrors++;
            break;
    }
    
    /* Reset timeout and error counters on successful message reception */
    g_CanCommHandler.timeoutCounter = 0;
    g_CanCommHandler.errorCounter = 0;
    
    /* Update state to normal if recovering from error */
    if(g_CanCommHandler.state != CAN_HANDLER_STATE_NORMAL)
    {
        g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
        g_CanCommHandler.retryCounter = 0;
    }
}

/**
 * @brief Handle CAN bus-off event
 */
void CanCommHandler_BusOffNotification(uint8 ControllerId)
{
    g_CanCommHandler.state = CAN_HANDLER_STATE_BUS_OFF;
    g_CanCommHandler.errorCounter++;
    
    /* Notify odometer manager about communication loss */
    OdometerManager_HandleCanTimeout();
    
    /* Report to DET */
    Det_ReportError(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                   CAN_HANDLER_API_BUS_OFF_NOTIFICATION, CAN_HANDLER_E_BUS_OFF);
}

/**
 * @brief Handle CAN error event
 */
void CanCommHandler_ErrorNotification(uint8 ControllerId, Can_ErrorStateType ErrorState)
{
    g_CanCommHandler.errorCounter++;
    
    switch(ErrorState)
    {
        case CAN_ERRORSTATE_ACTIVE:
            /* Normal operation */
            if(g_CanCommHandler.state == CAN_HANDLER_STATE_ERROR_PASSIVE)
            {
                g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
            }
            break;
            
        case CAN_ERRORSTATE_PASSIVE:
            g_CanCommHandler.state = CAN_HANDLER_STATE_ERROR_PASSIVE;
            break;
            
        case CAN_ERRORSTATE_BUSOFF:
            g_CanCommHandler.state = CAN_HANDLER_STATE_BUS_OFF;
            OdometerManager_HandleCanTimeout();
            break;
            
        default:
            g_CanCommHandler.state = CAN_HANDLER_STATE_CRITICAL_ERROR;
            break;
    }
    
    /* Report to DET */
    Det_ReportError(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                   CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
}

/**
 * @brief Get current communication status
 */
CanHandlerState_t CanCommHandler_GetStatus(void)
{
    return g_CanCommHandler.state;
}

/**
 * @brief Get last valid odometer message
 */
Std_ReturnType CanCommHandler_GetLastOdometerMessage(OdometerCanMessage_t* messagePtr)
{
    if((messagePtr == NULL_PTR) || !g_CanCommHandler.lastMessage.isValid)
    {
        return E_NOT_OK;
    }
    
    *messagePtr = g_CanCommHandler.lastMessage;
    return E_OK;
}

/**
 * @brief Check if communication is healthy
 */
boolean CanCommHandler_IsCommunicationHealthy(void)
{
    return (g_CanCommHandler.state == CAN_HANDLER_STATE_NORMAL) &&
           ((g_SystemTickCan - g_CanCommHandler.lastMessageTime) < CAN_TIMEOUT_THRESHOLD);
}

/**
 * @brief Reset communication handler
 */
void CanCommHandler_Reset(void)
{
    g_CanCommHandler.errorCounter = 0;
    g_CanCommHandler.retryCounter = 0;
    g_CanCommHandler.timeoutCounter = 0;
    g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
}

/**
 * @brief Get communication statistics
 */
Std_ReturnType CanCommHandler_GetStatistics(uint32* totalMessages, uint32* totalErrors)
{
    if((totalMessages == NULL_PTR) || (totalErrors == NULL_PTR))
    {
        return E_NOT_OK;
    }
    
    *totalMessages = g_CanCommHandler.totalMessagesReceived;
    *totalErrors = g_CanCommHandler.totalMessageErrors;
    
    return E_OK;
}

/*******************************************************************************
 * LOCAL FUNCTION IMPLEMENTATIONS
 *******************************************************************************/

/**
 * @brief Process odometer CAN message
 */
static void CanCommHandler_ProcessOdometerMessage(const PduInfoType* PduInfoPtr)
{
    uint32 odometerValue;
    
    if(!CanCommHandler_ValidateMessage(PduInfoPtr, CAN_ODOMETER_MSG_LENGTH))
    {
        g_CanCommHandler.totalMessageErrors++;
        return;
    }
    
    /* Extract odometer value from CAN message */
    odometerValue = CanCommHandler_ExtractOdometerValue(PduInfoPtr->SduDataPtr);
    
    /* Update last message information */
    g_CanCommHandler.lastMessage.odometerValue = odometerValue;
    g_CanCommHandler.lastMessage.timestamp = g_SystemTickCan;
    g_CanCommHandler.lastMessage.isValid = TRUE;
    
    /* Forward to odometer manager for validation and processing */
    OdometerManager_UpdateValue(odometerValue, g_CanCommHandler.lastMessage.speedValue);
}

/**
 * @brief Process speed CAN message
 */
static void CanCommHandler_ProcessSpeedMessage(const PduInfoType* PduInfoPtr)
{
    uint16 speedValue;
    
    if(!CanCommHandler_ValidateMessage(PduInfoPtr, CAN_SPEED_MSG_LENGTH))
    {
        g_CanCommHandler.totalMessageErrors++;
        return;
    }
    
    /* Extract speed value from CAN message */
    speedValue = CanCommHandler_ExtractSpeedValue(PduInfoPtr->SduDataPtr);
    
    /* Update last message information */
    g_CanCommHandler.lastMessage.speedValue = speedValue;
    g_CanCommHandler.lastMessage.timestamp = g_SystemTickCan;
    
    /* If we have both odometer and speed, update the manager */
    if(g_CanCommHandler.lastMessage.isValid)
    {
        OdometerManager_UpdateValue(g_CanCommHandler.lastMessage.odometerValue, speedValue);
    }
}

/**
 * @brief Extract odometer value from CAN data
 */
static uint32 CanCommHandler_ExtractOdometerValue(const uint8* data)
{
    uint32 value = 0;
    
    /* Assuming little-endian format */
    value = (uint32)data[0] |
            ((uint32)data[1] << 8) |
            ((uint32)data[2] << 16) |
            ((uint32)data[3] << 24);
    
    return value;
}

/**
 * @brief Extract speed value from CAN data
 */
static uint16 CanCommHandler_ExtractSpeedValue(const uint8* data)
{
    uint16 value = 0;
    
    /* Assuming little-endian format */
    value = (uint16)data[0] | ((uint16)data[1] << 8);
    
    return value;
}

/**
 * @brief Validate CAN message
 */
static boolean CanCommHandler_ValidateMessage(const PduInfoType* PduInfoPtr, uint8 expectedLength)
{
    if((PduInfoPtr == NULL_PTR) || (PduInfoPtr->SduDataPtr == NULL_PTR))
    {
        return FALSE;
    }
    
    if(PduInfoPtr->SduLength != expectedLength)
    {
        return FALSE;
    }
    
    /* Additional validation can be added here (CRC, counter, etc.) */
    
    return TRUE;
}

/**
 * @brief Update state machine
 */
static void CanCommHandler_UpdateStateMachine(void)
{
    /* State machine logic - can be expanded based on requirements */
    switch(g_CanCommHandler.state)
    {
        case CAN_HANDLER_STATE_INIT:
            /* Initialization complete, move to normal */
            g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
            break;
            
        case CAN_HANDLER_STATE_NORMAL:
            /* Normal operation - handled in other functions */
            break;
            
        case CAN_HANDLER_STATE_TIMEOUT:
            /* Timeout handling - check for recovery */
            if((g_SystemTickCan - g_CanCommHandler.lastMessageTime) < CAN_TIMEOUT_THRESHOLD)
            {
                g_CanCommHandler.state = CAN_HANDLER_STATE_NORMAL;
            }
            break;
            
        case CAN_HANDLER_STATE_BUS_OFF:
        case CAN_HANDLER_STATE_ERROR_PASSIVE:
        case CAN_HANDLER_STATE_CRITICAL_ERROR:
            /* Error states - handled in main function and callbacks */
            break;
            
        default:
            g_CanCommHandler.state = CAN_HANDLER_STATE_CRITICAL_ERROR;
            break;
    }
}

/**
 * @brief Handle communication timeout
 */
static void CanCommHandler_HandleTimeout(void)
{
    g_CanCommHandler.timeoutCounter++;
    g_CanCommHandler.state = CAN_HANDLER_STATE_TIMEOUT;
    
    /* Invalidate last message */
    g_CanCommHandler.lastMessage.isValid = FALSE;
    
    /* Notify odometer manager */
    OdometerManager_HandleCanTimeout();
}