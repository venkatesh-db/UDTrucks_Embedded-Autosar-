/*******************************************************************************
 * File: ComStack_Types.h
 * Description: AUTOSAR Communication Stack Types
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Defines communication stack types for AUTOSAR
 *******************************************************************************/

#ifndef COMSTACK_TYPES_H
#define COMSTACK_TYPES_H

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "Std_Types.h"

/*******************************************************************************
 * TYPE DEFINITIONS
 *******************************************************************************/
typedef uint16 PduIdType;
typedef uint16 PduLengthType;

typedef struct {
    uint8* SduDataPtr;
    PduLengthType SduLength;
} PduInfoType;

typedef enum {
    BUFREQ_OK = 0,
    BUFREQ_E_NOT_OK,
    BUFREQ_E_BUSY,
    BUFREQ_E_OVFL
} BufReq_ReturnType;

typedef enum {
    TP_DATACONF = 0,
    TP_DATARETRY,
    TP_CONFPENDING
} TpDataStateType;

typedef struct {
    TpDataStateType TpDataState;
    PduLengthType TxTpDataCnt;
} RetryInfoType;

#endif /* COMSTACK_TYPES_H */