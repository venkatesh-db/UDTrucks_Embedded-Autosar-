/*******************************************************************************
 * File: CanCommHandler.h
 * Description: CAN Communication Handler for Odometer Data
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Handles CAN communication for odometer data with robust error detection
 *          and timeout handling to prevent data jumps during communication loss
 *******************************************************************************/

#ifndef CAN_COMM_HANDLER_H
#define CAN_COMM_HANDLER_H

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "Std_Types.h"
#include "ComStack_Types.h"
#include "CanIf.h"
#include "Com.h"

/*******************************************************************************
 * DEFINES AND MACROS
 *******************************************************************************/
#define CAN_ODOMETER_MSG_ID             0x123U   /* CAN message ID for odometer data */
#define CAN_SPEED_MSG_ID                0x456U   /* CAN message ID for speed data */
#define CAN_TIMEOUT_THRESHOLD           1000U    /* Timeout threshold in ms */
#define CAN_MAX_RETRY_COUNT             3U       /* Maximum retry count */
#define CAN_BUS_OFF_RECOVERY_TIME       5000U    /* Bus-off recovery time in ms */

/* Message length definitions */
#define CAN_ODOMETER_MSG_LENGTH         8U
#define CAN_SPEED_MSG_LENGTH            8U

/* Signal positions in CAN messages */
#define ODOMETER_VALUE_START_BIT        0U
#define ODOMETER_VALUE_LENGTH           32U
#define SPEED_VALUE_START_BIT           0U
#define SPEED_VALUE_LENGTH              16U

/*******************************************************************************
 * TYPE DEFINITIONS
 *******************************************************************************/
typedef enum {
    CAN_HANDLER_STATE_INIT = 0,
    CAN_HANDLER_STATE_NORMAL,
    CAN_HANDLER_STATE_TIMEOUT,
    CAN_HANDLER_STATE_BUS_OFF,
    CAN_HANDLER_STATE_ERROR_PASSIVE,
    CAN_HANDLER_STATE_CRITICAL_ERROR
} CanHandlerState_t;

typedef struct {
    uint32 odometerValue;        /* Odometer value from CAN */
    uint16 speedValue;           /* Speed value from CAN */
    uint32 timestamp;            /* Message timestamp */
    boolean isValid;             /* Message validity flag */
} OdometerCanMessage_t;

typedef struct {
    CanHandlerState_t state;          /* Current handler state */
    uint32 lastMessageTime;           /* Timestamp of last message */
    uint32 timeoutCounter;            /* Timeout counter */
    uint32 errorCounter;              /* Error counter */
    uint32 retryCounter;              /* Retry counter */
    boolean isInitialized;            /* Initialization flag */
    OdometerCanMessage_t lastMessage; /* Last received message */
    uint32 totalMessagesReceived;     /* Statistics counter */
    uint32 totalMessageErrors;        /* Error statistics */
} CanCommHandler_t;

/*******************************************************************************
 * FUNCTION PROTOTYPES
 *******************************************************************************/

/**
 * @brief Initialize CAN Communication Handler
 * @param None
 * @return Std_ReturnType - E_OK if successful, E_NOT_OK if failed
 */
Std_ReturnType CanCommHandler_Init(void);

/**
 * @brief Main function to be called cyclically
 * @param None
 * @return None
 */
void CanCommHandler_MainFunction(void);

/**
 * @brief CAN message reception callback
 * @param RxPduId - PDU ID of received message
 * @param PduInfoPtr - Pointer to PDU information
 * @return None
 */
void CanCommHandler_RxIndication(PduIdType RxPduId, const PduInfoType* PduInfoPtr);

/**
 * @brief Handle CAN bus-off event
 * @param ControllerId - CAN controller ID
 * @return None
 */
void CanCommHandler_BusOffNotification(uint8 ControllerId);

/**
 * @brief Handle CAN error event
 * @param ControllerId - CAN controller ID
 * @param ErrorState - Error state information
 * @return None
 */
void CanCommHandler_ErrorNotification(uint8 ControllerId, Can_ErrorStateType ErrorState);

/**
 * @brief Get current communication status
 * @param None
 * @return CanHandlerState_t - Current communication state
 */
CanHandlerState_t CanCommHandler_GetStatus(void);

/**
 * @brief Get last valid odometer message
 * @param messagePtr - Pointer to store message data
 * @return Std_ReturnType - E_OK if valid data available, E_NOT_OK otherwise
 */
Std_ReturnType CanCommHandler_GetLastOdometerMessage(OdometerCanMessage_t* messagePtr);

/**
 * @brief Check if communication is healthy
 * @param None
 * @return boolean - TRUE if healthy, FALSE if not
 */
boolean CanCommHandler_IsCommunicationHealthy(void);

/**
 * @brief Reset communication handler
 * @param None
 * @return None
 */
void CanCommHandler_Reset(void);

/**
 * @brief Get communication statistics
 * @param totalMessages - Pointer to store total message count
 * @param totalErrors - Pointer to store total error count
 * @return Std_ReturnType - E_OK if successful
 */
Std_ReturnType CanCommHandler_GetStatistics(uint32* totalMessages, uint32* totalErrors);

#endif /* CAN_COMM_HANDLER_H */