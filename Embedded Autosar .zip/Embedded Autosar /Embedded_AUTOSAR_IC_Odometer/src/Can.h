/*******************************************************************************
 * File: Can.h
 * Description: AUTOSAR CAN Driver Interface
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: CAN driver interface definitions and types
 *******************************************************************************/

#ifndef CAN_H
#define CAN_H

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "Std_Types.h"
#include "ComStack_Types.h"

/*******************************************************************************
 * TYPE DEFINITIONS
 *******************************************************************************/
typedef enum {
    CAN_ERRORSTATE_ACTIVE = 0,
    CAN_ERRORSTATE_PASSIVE,
    CAN_ERRORSTATE_BUSOFF
} Can_ErrorStateType;

typedef enum {
    CAN_CS_UNINIT = 0,
    CAN_CS_READY,
    CAN_CS_STARTED,
    CAN_CS_STOPPED,
    CAN_CS_SLEEP
} Can_ControllerStateType;

typedef uint8 Can_HwHandleType;
typedef uint16 Can_IdType;

typedef struct {
    Can_IdType id;
    Can_HwHandleType hoh;
    uint8 length;
    uint8 sdu[8];
} Can_PduType;

/*******************************************************************************
 * ERROR DEFINITIONS
 *******************************************************************************/
#define CAN_MODULE_ID           80U
#define CAN_INSTANCE_ID         0U

#define CAN_E_PARAM_POINTER     0x01U
#define CAN_E_PARAM_HANDLE      0x02U
#define CAN_E_PARAM_DLC         0x03U
#define CAN_E_PARAM_CONTROLLER  0x04U
#define CAN_E_UNINIT            0x05U
#define CAN_E_TRANSITION        0x06U

/*******************************************************************************
 * API IDS
 *******************************************************************************/
#define CAN_API_INIT                    0x00U
#define CAN_API_DEINIT                  0x10U
#define CAN_API_WRITE                   0x06U
#define CAN_API_SET_CONTROLLER_MODE     0x03U

/*******************************************************************************
 * FUNCTION PROTOTYPES
 *******************************************************************************/
void Can_Init(const void* Config);
void Can_DeInit(void);
Std_ReturnType Can_SetControllerMode(uint8 Controller, Can_ControllerStateType Transition);
Std_ReturnType Can_Write(Can_HwHandleType Hth, const Can_PduType* PduInfo);
void Can_MainFunction_Write(void);
void Can_MainFunction_Read(void);
void Can_MainFunction_BusOff(void);

#endif /* CAN_H */