/*******************************************************************************
 * File: OdometerManager.h
 * Description: AUTOSAR IC Odometer Manager Header File
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Manages odometer value handling with CAN communication loss protection
 *          Prevents odometer value jumps during CAN bus failures
 *******************************************************************************/

#ifndef ODOMETER_MANAGER_H
#define ODOMETER_MANAGER_H

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "Std_Types.h"
#include "ComM.h"
#include "Can.h"
#include "CanIf.h"
#include "PduR.h"
#include "NvM.h"

/*******************************************************************************
 * DEFINES AND MACROS
 *******************************************************************************/
#define ODOMETER_CAN_TIMEOUT_MS         1000U    /* 1 second timeout */
#define ODOMETER_MAX_JUMP_THRESHOLD     100U     /* Maximum allowed jump in km/h */
#define ODOMETER_INVALID_VALUE          0xFFFFU  /* Invalid odometer value */
#define ODOMETER_NVM_BLOCK_ID          1U       /* NVM block for odometer storage */
#define ODOMETER_SPEED_FILTER_SAMPLES   5U      /* Number of samples for filtering */

/*******************************************************************************
 * TYPE DEFINITIONS
 *******************************************************************************/
typedef enum {
    ODOMETER_STATE_INIT = 0,
    ODOMETER_STATE_NORMAL_OPERATION,
    ODOMETER_STATE_CAN_TIMEOUT,
    ODOMETER_STATE_COMMUNICATION_LOST,
    ODOMETER_STATE_ERROR
} OdometerState_t;

typedef enum {
    CAN_COMM_OK = 0,
    CAN_COMM_TIMEOUT,
    CAN_COMM_BUS_OFF,
    CAN_COMM_ERROR_PASSIVE,
    CAN_COMM_NO_COMMUNICATION
} CanCommStatus_t;

typedef struct {
    uint32 currentOdometerValue;     /* Current odometer reading in meters */
    uint32 lastValidOdometerValue;   /* Last valid odometer reading */
    uint32 nvmBackupValue;           /* NVM backup value */
    uint16 currentSpeed;             /* Current vehicle speed in km/h * 10 */
    uint16 lastValidSpeed;           /* Last valid speed value */
    uint32 lastUpdateTime;           /* Timestamp of last update */
    uint32 canTimeoutCounter;        /* CAN timeout counter */
    OdometerState_t state;           /* Current odometer state */
    CanCommStatus_t canStatus;       /* CAN communication status */
    boolean isInitialized;           /* Initialization flag */
    boolean dataValid;               /* Data validity flag */
    uint16 speedFilterBuffer[ODOMETER_SPEED_FILTER_SAMPLES]; /* Speed filter buffer */
    uint8 filterIndex;               /* Filter buffer index */
} OdometerManager_t;

/*******************************************************************************
 * FUNCTION PROTOTYPES
 *******************************************************************************/

/**
 * @brief Initialize the Odometer Manager
 * @param None
 * @return Std_ReturnType - E_OK if successful, E_NOT_OK if failed
 */
Std_ReturnType OdometerManager_Init(void);

/**
 * @brief Main function to be called cyclically
 * @param None
 * @return None
 */
void OdometerManager_MainFunction(void);

/**
 * @brief Update odometer value from CAN message
 * @param odometerValue - New odometer value from CAN
 * @param speedValue - Current speed value
 * @return Std_ReturnType - E_OK if accepted, E_NOT_OK if rejected
 */
Std_ReturnType OdometerManager_UpdateValue(uint32 odometerValue, uint16 speedValue);

/**
 * @brief Get current odometer value
 * @param odometerValue - Pointer to store odometer value
 * @return Std_ReturnType - E_OK if valid, E_NOT_OK if invalid
 */
Std_ReturnType OdometerManager_GetValue(uint32* odometerValue);

/**
 * @brief Handle CAN communication timeout
 * @param None
 * @return None
 */
void OdometerManager_HandleCanTimeout(void);

/**
 * @brief Handle CAN communication recovery
 * @param None
 * @return None
 */
void OdometerManager_HandleCanRecovery(void);

/**
 * @brief Validate odometer value to prevent jumps
 * @param newValue - New odometer value to validate
 * @param currentSpeed - Current vehicle speed
 * @return boolean - TRUE if valid, FALSE if invalid
 */
boolean OdometerManager_ValidateOdometerValue(uint32 newValue, uint16 currentSpeed);

/**
 * @brief Save odometer value to NVM
 * @param None
 * @return Std_ReturnType - E_OK if successful, E_NOT_OK if failed
 */
Std_ReturnType OdometerManager_SaveToNvm(void);

/**
 * @brief Load odometer value from NVM
 * @param None
 * @return Std_ReturnType - E_OK if successful, E_NOT_OK if failed
 */
Std_ReturnType OdometerManager_LoadFromNvm(void);

/**
 * @brief Get current odometer state
 * @param None
 * @return OdometerState_t - Current state
 */
OdometerState_t OdometerManager_GetState(void);

/**
 * @brief Reset odometer manager (for diagnostic purposes)
 * @param None
 * @return None
 */
void OdometerManager_Reset(void);

#endif /* ODOMETER_MANAGER_H */