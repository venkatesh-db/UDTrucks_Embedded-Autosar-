/*******************************************************************************
 * File: mock_NvM.c
 * Description: Mock implementation for AUTOSAR NvM module
 *******************************************************************************/

#include "mock_NvM.h"
#include "unity.h"
#include <stdbool.h>

/* Mock state variables */
static Std_ReturnType mock_NvM_ReadBlock_return_val = E_OK;
static Std_ReturnType mock_NvM_WriteBlock_return_val = E_OK;
static bool mock_NvM_ReadBlock_expect_called = false;
static bool mock_NvM_WriteBlock_expect_called = false;
static bool mock_ignore_dst_ptr = false;
static bool mock_ignore_src_ptr = false;

/* Mock function implementations */
Std_ReturnType NvM_ReadBlock(uint16 BlockId, void* NvM_DstPtr)
{
    (void)BlockId;
    
    if (!mock_ignore_dst_ptr && NvM_DstPtr != NULL) {
        /* Simulate successful read by setting some data */
        *((uint32*)NvM_DstPtr) = 50000; /* Default odometer value */
    }
    
    return mock_NvM_ReadBlock_return_val;
}

Std_ReturnType NvM_WriteBlock(uint16 BlockId, const void* NvM_SrcPtr)
{
    (void)BlockId;
    (void)NvM_SrcPtr;
    return mock_NvM_WriteBlock_return_val;
}

/* Mock expectation functions */
Std_ReturnType NvM_ReadBlock_ExpectAndReturn(uint16 BlockId, void* NvM_DstPtr, Std_ReturnType retval)
{
    (void)BlockId;
    (void)NvM_DstPtr;
    mock_NvM_ReadBlock_return_val = retval;
    mock_NvM_ReadBlock_expect_called = true;
    return retval;
}

void NvM_ReadBlock_IgnoreArg_NvM_DstPtr(void)
{
    mock_ignore_dst_ptr = true;
}

Std_ReturnType NvM_WriteBlock_ExpectAndReturn(uint16 BlockId, const void* NvM_SrcPtr, Std_ReturnType retval)
{
    (void)BlockId;
    (void)NvM_SrcPtr;
    mock_NvM_WriteBlock_return_val = retval;
    mock_NvM_WriteBlock_expect_called = true;
    return retval;
}

void NvM_WriteBlock_IgnoreArg_NvM_SrcPtr(void)
{
    mock_ignore_src_ptr = true;
}

/* Reset function for test setup */
void mock_NvM_Reset(void)
{
    mock_NvM_ReadBlock_return_val = E_OK;
    mock_NvM_WriteBlock_return_val = E_OK;
    mock_NvM_ReadBlock_expect_called = false;
    mock_NvM_WriteBlock_expect_called = false;
    mock_ignore_dst_ptr = false;
    mock_ignore_src_ptr = false;
}