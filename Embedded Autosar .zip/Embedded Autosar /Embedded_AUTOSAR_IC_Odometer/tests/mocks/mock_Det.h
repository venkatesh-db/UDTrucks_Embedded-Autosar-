/*******************************************************************************
 * File: mock_Det.h
 * Description: Mock header for AUTOSAR DET module
 *******************************************************************************/

#ifndef MOCK_DET_H
#define MOCK_DET_H

#include "Std_Types.h"
#include <stdbool.h>

/* Mock function declarations */
void Det_ReportError_Expect(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);
void Det_ReportRuntimeError_Expect(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);

/* Mock implementations */
void Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);
void Det_ReportRuntimeError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);

/* Mock control functions */
void mock_Det_Reset(void);
bool mock_Det_WasErrorCalled(void);

#endif /* MOCK_DET_H */