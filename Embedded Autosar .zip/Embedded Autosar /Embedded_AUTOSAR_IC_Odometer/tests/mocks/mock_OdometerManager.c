/*******************************************************************************
 * File: mock_OdometerManager.c
 * Description: Mock implementation for OdometerManager module
 *******************************************************************************/

#include "mock_OdometerManager.h"
#include "unity.h"

/* Mock function implementations */
void OdometerManager_UpdateValue_Expect(uint32 newValue)
{
    (void)newValue;
    /* Mock implementation - expect this function to be called */
}

uint32 OdometerManager_GetCurrentValue_ExpectAndReturn(uint32 retval)
{
    return retval;
}

OdometerState_t OdometerManager_GetState_ExpectAndReturn(OdometerState_t retval)
{
    return retval;
}