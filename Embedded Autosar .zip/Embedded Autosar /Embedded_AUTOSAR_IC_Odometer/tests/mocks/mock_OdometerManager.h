/*******************************************************************************
 * File: mock_OdometerManager.h
 * Description: Mock header for OdometerManager module
 *******************************************************************************/

#ifndef MOCK_ODOMETERMANAGER_H
#define MOCK_ODOMETERMANAGER_H

#include "Std_Types.h"
#include "OdometerManager.h"

/* Mock function declarations */
void OdometerManager_UpdateValue_Expect(uint32 newValue);
uint32 OdometerManager_GetCurrentValue_ExpectAndReturn(uint32 retval);
OdometerState_t OdometerManager_GetState_ExpectAndReturn(OdometerState_t retval);

#endif /* MOCK_ODOMETERMANAGER_H */