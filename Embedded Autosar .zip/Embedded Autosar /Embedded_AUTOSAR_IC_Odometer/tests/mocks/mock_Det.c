/*******************************************************************************
 * File: mock_Det.c
 * Description: Mock implementation for AUTOSAR DET module
 *******************************************************************************/

#include "mock_Det.h"
#include "unity.h"
#include <stdbool.h>

/* Mock state tracking */
static struct {
    bool error_expected;
    uint16 expected_module_id;
    uint8 expected_instance_id;
    uint8 expected_api_id;
    uint8 expected_error_id;
    bool error_called;
} mock_det_state = {false, 0, 0, 0, 0, false};

/* Mock function implementations */
void Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId)
{
    mock_det_state.error_called = true;
    
    /* Verify expected values if expectation was set */
    if (mock_det_state.error_expected) {
        TEST_ASSERT_EQUAL_UINT16(mock_det_state.expected_module_id, ModuleId);
        TEST_ASSERT_EQUAL_UINT8(mock_det_state.expected_instance_id, InstanceId);
        TEST_ASSERT_EQUAL_UINT8(mock_det_state.expected_api_id, ApiId);
        TEST_ASSERT_EQUAL_UINT8(mock_det_state.expected_error_id, ErrorId);
    }
}

void Det_ReportRuntimeError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId)
{
    /* Similar to Det_ReportError for this implementation */
    Det_ReportError(ModuleId, InstanceId, ApiId, ErrorId);
}

void Det_ReportError_Expect(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId)
{
    mock_det_state.error_expected = true;
    mock_det_state.expected_module_id = ModuleId;
    mock_det_state.expected_instance_id = InstanceId;
    mock_det_state.expected_api_id = ApiId;
    mock_det_state.expected_error_id = ErrorId;
    mock_det_state.error_called = false;
}

void Det_ReportRuntimeError_Expect(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId)
{
    Det_ReportError_Expect(ModuleId, InstanceId, ApiId, ErrorId);
}

/* Mock control functions */
void mock_Det_Reset(void)
{
    mock_det_state.error_expected = false;
    mock_det_state.expected_module_id = 0;
    mock_det_state.expected_instance_id = 0;
    mock_det_state.expected_api_id = 0;
    mock_det_state.expected_error_id = 0;
    mock_det_state.error_called = false;
}

bool mock_Det_WasErrorCalled(void)
{
    return mock_det_state.error_called;
}