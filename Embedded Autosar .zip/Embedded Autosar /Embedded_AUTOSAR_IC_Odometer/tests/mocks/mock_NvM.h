/*******************************************************************************
 * File: mock_NvM.h
 * Description: Mock header for AUTOSAR NvM module
 *******************************************************************************/

#ifndef MOCK_NVM_H
#define MOCK_NVM_H

#include "Std_Types.h"

/* Mock function declarations */
Std_ReturnType NvM_ReadBlock_ExpectAndReturn(uint16 BlockId, void* NvM_DstPtr, Std_ReturnType retval);
void NvM_ReadBlock_IgnoreArg_NvM_DstPtr(void);
Std_ReturnType NvM_WriteBlock_ExpectAndReturn(uint16 BlockId, const void* NvM_SrcPtr, Std_ReturnType retval);
void NvM_WriteBlock_IgnoreArg_NvM_SrcPtr(void);

/* Mock implementations */
Std_ReturnType NvM_ReadBlock(uint16 BlockId, void* NvM_DstPtr);
Std_ReturnType NvM_WriteBlock(uint16 BlockId, const void* NvM_SrcPtr);

/* Mock control functions */
void mock_NvM_Reset(void);

#endif /* MOCK_NVM_H */