/*******************************************************************************
 * File: NvM.h
 * Description: Simplified Non-Volatile Memory header for testing
 *******************************************************************************/

#ifndef NVM_H
#define NVM_H

#include "Std_Types.h"

/* NVM Block management types */
typedef enum {
    NVM_REQ_OK = 0,
    NVM_REQ_NOT_OK,
    NVM_REQ_PENDING,
    NVM_REQ_INTEGRITY_FAILED,
    NVM_REQ_BLOCK_SKIPPED,
    NVM_REQ_NV_INVALIDATED,
    NVM_REQ_CANCELED,
    NVM_REQ_REDUNDANCY_FAILED,
    NVM_REQ_RESTORED_FROM_ROM
} NvM_RequestResultType;

/* Function declarations */
Std_ReturnType NvM_ReadBlock(uint16 BlockId, void* NvM_DstPtr);
Std_ReturnType NvM_WriteBlock(uint16 BlockId, const void* NvM_SrcPtr);
Std_ReturnType NvM_GetErrorStatus(uint16 BlockId, NvM_RequestResultType* RequestResultPtr);

#endif /* NVM_H */