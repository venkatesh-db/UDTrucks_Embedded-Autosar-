/*******************************************************************************
 * File: test_CanCommHandler.c  
 * Description: Unit Tests for CAN Communication Handler
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Test suite for CAN communication handling and error recovery
 *******************************************************************************/

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "unity.h"
#include "CanCommHandler.h"
#include "mock_OdometerManager.h"
#include "mock_Det.h"

/*******************************************************************************
 * TEST DATA
 *******************************************************************************/
static uint8 test_odometer_data[8] = {0x00, 0x86, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00}; /* 100000 meters */
static uint8 test_speed_data[8] = {0xF4, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};    /* 500 = 50 km/h */

/*******************************************************************************
 * TEST FIXTURES
 *******************************************************************************/
void setUp(void)
{
    CanCommHandler_Init();
}

void tearDown(void)
{
    CanCommHandler_Reset();
}

/*******************************************************************************
 * TEST CASES - INITIALIZATION
 *******************************************************************************/
void test_CanCommHandler_Init_Success(void)
{
    /* Act */
    Std_ReturnType result = CanCommHandler_Init();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
    TEST_ASSERT_TRUE(CanCommHandler_IsCommunicationHealthy());
}

/*******************************************************************************
 * TEST CASES - MESSAGE RECEPTION
 *******************************************************************************/
void test_CanCommHandler_RxIndication_OdometerMessage_Valid(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 8;
    
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    
    /* Act */
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
    
    /* Verify last message can be retrieved */
    OdometerCanMessage_t lastMessage;
    Std_ReturnType result = CanCommHandler_GetLastOdometerMessage(&lastMessage);
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(100000, lastMessage.odometerValue);
    TEST_ASSERT_TRUE(lastMessage.isValid);
}

void test_CanCommHandler_RxIndication_SpeedMessage_Valid(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_speed_data;
    pduInfo.SduLength = 8;
    
    /* First receive odometer message to make last message valid */
    PduInfoType odometerPdu;
    odometerPdu.SduDataPtr = test_odometer_data;
    odometerPdu.SduLength = 8;
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &odometerPdu);
    
    /* Now test speed message */
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 500, E_OK);
    
    /* Act */
    CanCommHandler_RxIndication(CAN_SPEED_MSG_ID, &pduInfo);
    
    /* Assert */
    OdometerCanMessage_t lastMessage;
    CanCommHandler_GetLastOdometerMessage(&lastMessage);
    TEST_ASSERT_EQUAL(500, lastMessage.speedValue);
}

void test_CanCommHandler_RxIndication_InvalidLength(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 4; /* Invalid length */
    
    /* Act */
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Assert */
    uint32 totalMessages, totalErrors;
    CanCommHandler_GetStatistics(&totalMessages, &totalErrors);
    TEST_ASSERT_EQUAL(1, totalErrors); /* Error should be counted */
}

void test_CanCommHandler_RxIndication_NullPointer(void)
{
    /* Act */
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, NULL);
    
    /* Assert */
    uint32 totalMessages, totalErrors;
    CanCommHandler_GetStatistics(&totalMessages, &totalErrors);
    TEST_ASSERT_EQUAL(1, totalErrors); /* Error should be counted */
}

void test_CanCommHandler_RxIndication_UnknownMessageId(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 8;
    
    /* Act */
    CanCommHandler_RxIndication(0x999, &pduInfo); /* Unknown message ID */
    
    /* Assert */
    uint32 totalMessages, totalErrors;
    CanCommHandler_GetStatistics(&totalMessages, &totalErrors);
    TEST_ASSERT_EQUAL(1, totalErrors); /* Error should be counted */
}

/*******************************************************************************
 * TEST CASES - ERROR HANDLING
 *******************************************************************************/
void test_CanCommHandler_BusOffNotification(void)
{
    /* Arrange */
    OdometerManager_HandleCanTimeout_Expect();
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_BUS_OFF_NOTIFICATION, CAN_HANDLER_E_BUS_OFF);
    
    /* Act */
    CanCommHandler_BusOffNotification(0);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_BUS_OFF, CanCommHandler_GetStatus());
    TEST_ASSERT_FALSE(CanCommHandler_IsCommunicationHealthy());
}

void test_CanCommHandler_ErrorNotification_ErrorPassive(void)
{
    /* Arrange */
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
    
    /* Act */
    CanCommHandler_ErrorNotification(0, CAN_ERRORSTATE_PASSIVE);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_ERROR_PASSIVE, CanCommHandler_GetStatus());
}

void test_CanCommHandler_ErrorNotification_BusOff(void)
{
    /* Arrange */
    OdometerManager_HandleCanTimeout_Expect();
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
    
    /* Act */
    CanCommHandler_ErrorNotification(0, CAN_ERRORSTATE_BUSOFF);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_BUS_OFF, CanCommHandler_GetStatus());
}

void test_CanCommHandler_ErrorNotification_Active_Recovery(void)
{
    /* Arrange - First go to error passive state */
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
    CanCommHandler_ErrorNotification(0, CAN_ERRORSTATE_PASSIVE);
    
    /* Act - Recover to active state */
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
    CanCommHandler_ErrorNotification(0, CAN_ERRORSTATE_ACTIVE);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
}

/*******************************************************************************
 * TEST CASES - TIMEOUT HANDLING
 *******************************************************************************/
void test_CanCommHandler_MainFunction_Timeout(void)
{
    /* Arrange - Simulate passage of time without messages */
    /* Note: This test would need time simulation or injection */
    
    /* Initialize and simulate timeout condition */
    /* In real implementation, this would involve time manipulation */
    
    /* For this test, we'll verify the timeout handling logic indirectly */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
    
    /* This test would be enhanced with time injection mechanisms */
}

/*******************************************************************************
 * TEST CASES - STATISTICS
 *******************************************************************************/
void test_CanCommHandler_Statistics_MessageCounting(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 8;
    
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    
    /* Act - Send multiple valid messages */
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Assert */
    uint32 totalMessages, totalErrors;
    Std_ReturnType result = CanCommHandler_GetStatistics(&totalMessages, &totalErrors);
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(2, totalMessages);
    TEST_ASSERT_EQUAL(0, totalErrors);
}

void test_CanCommHandler_Statistics_ErrorCounting(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 4; /* Invalid length */
    
    /* Act - Send invalid message */
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Assert */
    uint32 totalMessages, totalErrors;
    CanCommHandler_GetStatistics(&totalMessages, &totalErrors);
    TEST_ASSERT_EQUAL(1, totalMessages);
    TEST_ASSERT_EQUAL(1, totalErrors);
}

void test_CanCommHandler_Statistics_NullPointer(void)
{
    /* Act */
    Std_ReturnType result = CanCommHandler_GetStatistics(NULL, NULL);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

/*******************************************************************************
 * TEST CASES - MESSAGE RETRIEVAL
 *******************************************************************************/
void test_CanCommHandler_GetLastMessage_Valid(void)
{
    /* Arrange */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 8;
    
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Act */
    OdometerCanMessage_t message;
    Std_ReturnType result = CanCommHandler_GetLastOdometerMessage(&message);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(100000, message.odometerValue);
    TEST_ASSERT_TRUE(message.isValid);
}

void test_CanCommHandler_GetLastMessage_NoValidMessage(void)
{
    /* Arrange - No messages received */
    OdometerCanMessage_t message;
    
    /* Act */
    Std_ReturnType result = CanCommHandler_GetLastOdometerMessage(&message);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

void test_CanCommHandler_GetLastMessage_NullPointer(void)
{
    /* Act */
    Std_ReturnType result = CanCommHandler_GetLastOdometerMessage(NULL);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

/*******************************************************************************
 * TEST CASES - RESET FUNCTIONALITY
 *******************************************************************************/
void test_CanCommHandler_Reset(void)
{
    /* Arrange - Put handler in error state */
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_ERROR_NOTIFICATION, CAN_HANDLER_E_CAN_ERROR);
    CanCommHandler_ErrorNotification(0, CAN_ERRORSTATE_PASSIVE);
    
    /* Act */
    CanCommHandler_Reset();
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
}

/*******************************************************************************
 * TEST CASES - STATE RECOVERY
 *******************************************************************************/
void test_CanCommHandler_StateRecovery_AfterBusOff(void)
{
    /* Arrange - Enter bus-off state */
    OdometerManager_HandleCanTimeout_Expect();
    Det_ReportError_Expect(CAN_HANDLER_MODULE_ID, CAN_HANDLER_INSTANCE_ID, 
                          CAN_HANDLER_API_BUS_OFF_NOTIFICATION, CAN_HANDLER_E_BUS_OFF);
    CanCommHandler_BusOffNotification(0);
    
    /* Act - Receive valid message (simulates recovery) */
    PduInfoType pduInfo;
    pduInfo.SduDataPtr = test_odometer_data;
    pduInfo.SduLength = 8;
    OdometerManager_UpdateValue_ExpectAndReturn(100000, 0, E_OK);
    CanCommHandler_RxIndication(CAN_ODOMETER_MSG_ID, &pduInfo);
    
    /* Assert */
    TEST_ASSERT_EQUAL(CAN_HANDLER_STATE_NORMAL, CanCommHandler_GetStatus());
}

/*******************************************************************************
 * MAIN TEST RUNNER
 *******************************************************************************/
int main(void)
{
    UNITY_BEGIN();
    
    /* Initialization Tests */
    RUN_TEST(test_CanCommHandler_Init_Success);
    
    /* Message Reception Tests */
    RUN_TEST(test_CanCommHandler_RxIndication_OdometerMessage_Valid);
    RUN_TEST(test_CanCommHandler_RxIndication_SpeedMessage_Valid);
    RUN_TEST(test_CanCommHandler_RxIndication_InvalidLength);
    RUN_TEST(test_CanCommHandler_RxIndication_NullPointer);
    RUN_TEST(test_CanCommHandler_RxIndication_UnknownMessageId);
    
    /* Error Handling Tests */
    RUN_TEST(test_CanCommHandler_BusOffNotification);
    RUN_TEST(test_CanCommHandler_ErrorNotification_ErrorPassive);
    RUN_TEST(test_CanCommHandler_ErrorNotification_BusOff);
    RUN_TEST(test_CanCommHandler_ErrorNotification_Active_Recovery);
    
    /* Timeout Handling Tests */
    RUN_TEST(test_CanCommHandler_MainFunction_Timeout);
    
    /* Statistics Tests */
    RUN_TEST(test_CanCommHandler_Statistics_MessageCounting);
    RUN_TEST(test_CanCommHandler_Statistics_ErrorCounting);
    RUN_TEST(test_CanCommHandler_Statistics_NullPointer);
    
    /* Message Retrieval Tests */
    RUN_TEST(test_CanCommHandler_GetLastMessage_Valid);
    RUN_TEST(test_CanCommHandler_GetLastMessage_NoValidMessage);
    RUN_TEST(test_CanCommHandler_GetLastMessage_NullPointer);
    
    /* Reset and Recovery Tests */
    RUN_TEST(test_CanCommHandler_Reset);
    RUN_TEST(test_CanCommHandler_StateRecovery_AfterBusOff);
    
    return UNITY_END();
}