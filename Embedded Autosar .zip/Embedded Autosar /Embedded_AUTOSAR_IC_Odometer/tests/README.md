# AUTOSAR IC Odometer - Test Plan & Makefile

## Test Strategy

This directory contains comprehensive test suites for the AUTOSAR IC Odometer solution:

### Unit Tests
- `test_OdometerManager.c` - Tests for the core odometer management functionality
- `test_CanCommHandler.c` - Tests for CAN communication handling
- Integration test suites can be added as needed

### Test Framework
- **Unity**: C unit testing framework
- **CMock**: Mock generation for AUTOSAR modules
- **Ceedling**: Build automation for C projects with testing

### Test Coverage Areas

#### Functional Tests
1. **Initialization & Configuration**
2. **Message Reception & Validation** 
3. **Jump Detection & Prevention**
4. **Timeout Handling**
5. **Error Recovery**
6. **NVM Operations**
7. **State Management**

#### Robustness Tests
1. **Boundary Conditions**
2. **Error Injection**
3. **Resource Exhaustion**
4. **Invalid Input Handling**

#### Performance Tests
1. **Timing Validation**
2. **Memory Usage**
3. **CPU Load**

## Build Instructions

### Prerequisites
```bash
# Install Unity testing framework
git clone https://github.com/ThrowTheSwitch/Unity.git
cd Unity
make

# Install CMock for mocking
git clone https://github.com/ThrowTheSwitch/CMock.git
cd CMock
bundle install

# Install Ceedling (optional, for automated builds)
gem install ceedling
```

### Running Tests

#### Manual Build
```bash
# Compile test suite
gcc -I../src -I./unity/src -I./mocks \
    test_OdometerManager.c \
    unity/src/unity.c \
    mocks/mock_NvM.c \
    mocks/mock_Det.c \
    -o test_odometer_manager

# Run tests
./test_odometer_manager
```

#### Using Makefile
```bash
# Run all tests
make test

# Run specific test suite
make test_odometer
make test_can_handler

# Generate coverage report
make coverage

# Clean build artifacts
make clean
```

### Test Configuration

Test configuration files:
- `project.yml` - Ceedling project configuration
- `test_config.h` - Test-specific configurations
- Mock configurations for AUTOSAR modules

## Continuous Integration

### Automated Testing Pipeline
```yaml
# Example GitHub Actions workflow
name: AUTOSAR IC Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Install dependencies
      run: |
        sudo apt-get update
        sudo apt-get install gcc gcov lcov
    - name: Run tests
      run: make test
    - name: Generate coverage
      run: make coverage
    - name: Upload coverage
      uses: codecov/codecov-action@v1
```

### Quality Gates
- **Code Coverage**: Minimum 95% line coverage
- **Static Analysis**: MISRA-C compliance
- **Memory Leaks**: Valgrind validation
- **Performance**: Timing requirements validation

## Test Data & Scenarios

### Test Scenarios Matrix

| Scenario | Description | Expected Result |
|----------|-------------|-----------------|
| Normal Operation | Regular odometer updates | Values accepted |
| CAN Timeout | Communication loss | Fallback to last valid |
| Large Jump | Unrealistic value change | Value rejected |
| Speed Validation | Cross-check with speed | Plausible values only |
| NVM Failure | Storage operation fails | Graceful degradation |
| Bus-off Recovery | CAN bus recovery | Resume normal operation |
| Power Cycle | System restart | Restore from NVM |

### Mock Data Sets
- Normal driving patterns
- Highway vs city driving
- Vehicle stationary scenarios
- Communication error patterns
- Edge case value combinations

## Performance Benchmarks

### Target Metrics
- **Response Time**: < 10ms for value updates
- **Memory Usage**: < 2KB RAM, < 10KB ROM
- **CPU Load**: < 5% at 10ms cycle time
- **Recovery Time**: < 5 seconds after communication restore

### Benchmarking Tools
- Timing analysis with oscilloscope
- Memory profiling tools
- CPU utilization monitoring
- Static analysis tools (PC-lint, Polyspace)

## Integration Test Scenarios

### Hardware-in-Loop (HIL) Testing
1. **CAN Network Simulation**
   - Multiple ECU simulation
   - Network load variation
   - Error injection capabilities

2. **Real-time Validation**
   - Timing constraint verification
   - Interrupt response testing
   - Multi-tasking scenarios

3. **Environmental Testing**
   - Temperature variation
   - Voltage fluctuation
   - EMC compliance

### Vehicle-level Testing
1. **Normal Driving Cycles**
2. **Fault Injection Testing** 
3. **Long-duration Validation**
4. **Cross-platform Compatibility**

## Test Reporting

### Automated Reports
- Unit test results with pass/fail status
- Code coverage analysis
- Static analysis findings
- Performance benchmark results
- Memory usage analysis

### Manual Test Documentation
- Test procedure documentation
- Test result logging
- Defect tracking and resolution
- Validation sign-off documentation

## Troubleshooting

### Common Test Issues
1. **Mock Setup Problems**: Verify mock generation and linking
2. **Timing Dependencies**: Use dependency injection for time
3. **Hardware Dependencies**: Abstract hardware interfaces
4. **Memory Issues**: Check for proper cleanup in tearDown()

### Debug Techniques
- Unit test debugging with GDB
- Mock verification and validation
- Test isolation and dependency analysis
- Coverage gap analysis