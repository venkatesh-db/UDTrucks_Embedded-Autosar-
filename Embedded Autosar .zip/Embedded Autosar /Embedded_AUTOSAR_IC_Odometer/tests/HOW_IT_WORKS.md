/*******************************************************************************
 * AUTOSAR IC Odometer - HOW THE PROTECTION ALGORITHMS WORK
 * 
 * This document explains the internal workings of the trust/protection system
 *******************************************************************************/

# 🔐 HOW THE ODOMETER PROTECTION ALGORITHMS WORK

## 📊 Core Protection Mechanisms

### 1. **JUMP DETECTION ALGORITHM** 
```c
/**
 * The heart of the protection system - validates every new odometer value
 * Location: OdometerManager_ValidateOdometerValue() in OdometerManager.c:218
 */
boolean OdometerManager_ValidateOdometerValue(uint32 newValue, uint16 currentSpeed)
{
    // Step 1: Calculate expected value based on physics
    timeElapsed = g_SystemTick - g_OdometerManager.lastUpdateTime;
    expectedValue = OdometerManager_CalculateExpectedOdometer(
        g_OdometerManager.currentOdometerValue,
        g_OdometerManager.currentSpeed, 
        timeElapsed);
    
    // Step 2: Check if new value is within reasonable bounds
    return OdometerManager_IsValueReasonable(newValue, expectedValue);
}

/**
 * Physics-based calculation: distance = speed × time
 * Location: OdometerManager_CalculateExpectedOdometer() line 342
 */
static uint32 OdometerManager_CalculateExpectedOdometer(uint32 currentOdometer, 
                                                       uint16 speed, 
                                                       uint32 timeElapsed)
{
    // Convert: speed(km/h × 10) × time(ms) → distance(meters)
    uint32 distanceTraveled = (speed * timeElapsed) / 36000;
    return currentOdometer + distanceTraveled;
}

/**
 * Reasonableness check - prevents jumps > 1km
 * Location: OdometerManager_IsValueReasonable() line 358
 */
static boolean OdometerManager_IsValueReasonable(uint32 newValue, uint32 expectedValue)
{
    uint32 difference = abs(newValue - expectedValue);
    return (difference <= 1000);  // Max 1km jump allowed
}
```

### 2. **SPEED FILTERING ALGORITHM**
```c
/**
 * Moving average filter to smooth speed variations
 * Location: OdometerManager_FilterSpeed() line 317
 */
static uint16 OdometerManager_FilterSpeed(uint16 newSpeed)
{
    // Circular buffer - stores last 5 speed values
    g_OdometerManager.speedFilterBuffer[g_OdometerManager.filterIndex] = newSpeed;
    g_OdometerManager.filterIndex = (filterIndex + 1) % 5;
    
    // Calculate moving average
    uint32 sum = 0;
    for(i = 0; i < 5; i++) {
        sum += g_OdometerManager.speedFilterBuffer[i];
    }
    return (uint16)(sum / 5);
}
```

### 3. **CAN TIMEOUT PROTECTION**
```c
/**
 * Multi-level timeout handling
 * Location: OdometerManager_HandleCanTimeout() line 175
 */
void OdometerManager_HandleCanTimeout(void)
{
    g_OdometerManager.canTimeoutCounter++;
    
    if(canTimeoutCounter >= 3) {  // 3 consecutive timeouts (3 seconds)
        // CRITICAL: Freeze odometer - prevent false increments
        g_OdometerManager.state = ODOMETER_STATE_COMMUNICATION_LOST;
        g_OdometerManager.dataValid = FALSE;
        
        // Emergency backup to NVM
        OdometerManager_SaveToNvm();
    } else {
        // Temporary timeout - still recoverable
        g_OdometerManager.state = ODOMETER_STATE_CAN_TIMEOUT;
    }
}
```

### 4. **STATE MACHINE PROTECTION**
```c
/**
 * Robust state management prevents invalid transitions
 */
typedef enum {
    ODOMETER_STATE_INIT,                 // System starting up
    ODOMETER_STATE_NORMAL_OPERATION,     // Normal CAN communication
    ODOMETER_STATE_CAN_TIMEOUT,          // Temporary communication loss
    ODOMETER_STATE_COMMUNICATION_LOST,   // Extended communication failure  
    ODOMETER_STATE_ERROR                 // Critical error detected
} OdometerState_t;

// State transitions are carefully controlled:
// INIT → NORMAL (after NVM load success)
// NORMAL → TIMEOUT (after 1 second no CAN)
// TIMEOUT → LOST (after 3 consecutive timeouts)  
// LOST → NORMAL (after valid CAN recovery)
// ANY → ERROR (on validation failure)
```

## 🛡️ TRUST VERIFICATION LAYERS

### **Layer 1: Message Validation**
```c
// Location: CanCommHandler_ValidateMessage() in CanCommHandler.c
static boolean CanCommHandler_ValidateMessage(const PduInfoType* PduInfoPtr, 
                                            uint8 expectedLength)
{
    // Check message length
    if(PduInfoPtr->SduLength != expectedLength) return FALSE;
    
    // Check data pointer validity  
    if(PduInfoPtr->SduDataPtr == NULL_PTR) return FALSE;
    
    // Check checksum (if available)
    // Check sequence number (if available)
    
    return TRUE;
}
```

### **Layer 2: Value Plausibility** 
```c
// Location: OdometerManager_UpdateValue() line 118
Std_ReturnType OdometerManager_UpdateValue(uint32 odometerValue, uint16 speedValue)
{
    // Filter noise from speed sensor
    uint16 filteredSpeed = OdometerManager_FilterSpeed(speedValue);
    
    // CRITICAL: Validate against physics model
    if(OdometerManager_ValidateOdometerValue(odometerValue, filteredSpeed))
    {
        // Accept value - update system state
        g_OdometerManager.currentOdometerValue = odometerValue;
        g_OdometerManager.lastValidOdometerValue = odometerValue;
        g_OdometerManager.dataValid = TRUE;
        return E_OK;
    }
    else
    {
        // REJECT value - trigger DET error
        Det_ReportError(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                       ODOMETER_API_UPDATE_VALUE, ODOMETER_E_VALUE_JUMP_DETECTED);
        return E_NOT_OK;
    }
}
```

### **Layer 3: Temporal Consistency**
```c
// Location: OdometerManager_MainFunction() line 87  
void OdometerManager_MainFunction(void)
{
    // Called every 10ms - monitors temporal behavior
    
    // Check for CAN timeout every cycle
    if((g_SystemTick - lastUpdateTime) > ODOMETER_CAN_TIMEOUT_MS)
    {
        OdometerManager_HandleCanTimeout();
    }
    
    // Periodic NVM backup (every 5 seconds)
    if(((g_SystemTick % 5000) == 0) && g_OdometerManager.dataValid)
    {
        OdometerManager_SaveToNvm();
    }
}
```

## 🎯 REAL-WORLD ATTACK SCENARIOS & DEFENSES

### **Scenario 1: CAN Bus Attack - Spoofed High Value**
```
Attack:  Malicious CAN message: odometer = 999,999 km
Defense: Physics validation rejects (jump > 1km threshold)
Result:  Value rejected, DET error logged, odometer unchanged
Code:    OdometerManager_IsValueReasonable() returns FALSE
```

### **Scenario 2: CAN Bus Jamming**  
```
Attack:  CAN bus flooding/jamming prevents legitimate messages
Defense: Timeout detection freezes odometer at last valid value
Result:  No false increments, value preserved in NVM
Code:    OdometerManager_HandleCanTimeout() → COMMUNICATION_LOST state
```

### **Scenario 3: Gradual Value Manipulation**
```
Attack:  Small incremental increases (10km, 20km, 30km...)
Defense: Speed-based validation catches unrealistic increments  
Result:  Values rejected when exceeding physics model
Code:    CalculateExpectedOdometer() + IsValueReasonable()
```

### **Scenario 4: Replay Attack**
```  
Attack:  Replaying old CAN messages with lower odometer values
Defense: Monotonic increase validation (odometer never goes backward)
Result:  Backward movement rejected
Code:    Implicit in validation logic
```

## 📈 PERFORMANCE & RELIABILITY

### **Timing Requirements**
- **Main Function**: Called every 10ms (100Hz)
- **CAN Timeout**: Detected within 1 second  
- **NVM Backup**: Every 5 seconds during normal operation
- **State Recovery**: Immediate on valid CAN reception

### **Memory Protection**
- **NVM Backup**: Automatic preservation during power loss
- **Redundant Storage**: Last valid value + current value stored
- **Corruption Detection**: NVM read/write error handling

### **Error Handling**
- **DET Integration**: All errors reported to Diagnostic Event Manager
- **Graceful Degradation**: System remains functional during CAN loss
- **Recovery Mechanisms**: Automatic return to normal operation

This multilayered approach ensures the odometer value remains trustworthy even under adverse conditions like CAN bus attacks, hardware failures, or communication disruptions.