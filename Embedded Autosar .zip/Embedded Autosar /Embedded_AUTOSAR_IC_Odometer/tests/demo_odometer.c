/*******************************************************************************
 * File: demo_odometer.c
 * Description: Demo program showing AUTOSAR IC Odometer functionality
 *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

// Simplified AUTOSAR types for demo
typedef uint8_t Std_ReturnType;
#define E_OK     0x00U
#define E_NOT_OK 0x01U

typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uint8_t uint8;

// Demo Constants
#define ODOMETER_MAX_JUMP_THRESHOLD     100U     /* Maximum allowed jump in km/h */
#define ODOMETER_INVALID_VALUE          0xFFFFU  /* Invalid odometer value */
#define ODOMETER_SPEED_FILTER_SAMPLES   5U       /* Number of samples for filtering */

// Demo State Machine
typedef enum {
    ODOMETER_STATE_INIT = 0,
    ODOMETER_STATE_NORMAL_OPERATION,
    ODOMETER_STATE_CAN_TIMEOUT,
    ODOMETER_STATE_COMMUNICATION_LOST,
    ODOMETER_STATE_ERROR
} OdometerState_t;

// Global variables for demo
static uint32 currentOdometerValue = 50000; // 50,000 km initial value
static uint32 speedHistory[ODOMETER_SPEED_FILTER_SAMPLES] = {0};
static uint8 speedIndex = 0;
static OdometerState_t odometerState = ODOMETER_STATE_INIT;
static bool canCommunicationActive = true;

// Demo Functions
void PrintHeader(void)
{
    printf("\n");
    printf("========================================\n");
    printf("   AUTOSAR IC Odometer Demo System    \n");
    printf("========================================\n");
    printf("Purpose: Prevent odometer jumps during\n");
    printf("         CAN communication failures\n");
    printf("========================================\n\n");
}

uint32 CalculateAverageSpeed(void)
{
    uint32 sum = 0;
    for (int i = 0; i < ODOMETER_SPEED_FILTER_SAMPLES; i++) {
        sum += speedHistory[i];
    }
    return sum / ODOMETER_SPEED_FILTER_SAMPLES;
}

bool ValidateOdometerJump(uint32 currentValue, uint32 newValue, uint32 currentSpeed)
{
    uint32 difference = (newValue > currentValue) ? 
                       (newValue - currentValue) : (currentValue - newValue);
    
    // Calculate maximum allowed distance based on speed
    uint32 maxAllowedDistance = (currentSpeed * 2) / 60; // 2 minutes at current speed
    
    printf("   Jump Validation:\n");
    printf("     Current: %u km, New: %u km\n", currentValue, newValue);
    printf("     Difference: %u km, Max allowed: %u km\n", difference, maxAllowedDistance);
    
    if (difference > maxAllowedDistance && difference > ODOMETER_MAX_JUMP_THRESHOLD) {
        printf("     Result: JUMP DETECTED - Value rejected!\n");
        return false;
    }
    
    printf("     Result: Value accepted\n");
    return true;
}

void UpdateSpeedHistory(uint32 speed)
{
    speedHistory[speedIndex] = speed;
    speedIndex = (speedIndex + 1) % ODOMETER_SPEED_FILTER_SAMPLES;
}

void ProcessOdometerUpdate(uint32 newValue, uint32 currentSpeed, bool canActive)
{
    static uint32 lastValidValue = 50000;
    
    printf("\n--- Processing Odometer Update ---\n");
    printf("Input: New value = %u km, Speed = %u km/h, CAN = %s\n", 
           newValue, currentSpeed, canActive ? "ACTIVE" : "TIMEOUT");
    
    UpdateSpeedHistory(currentSpeed);
    uint32 avgSpeed = CalculateAverageSpeed();
    
    if (!canActive) {
        odometerState = ODOMETER_STATE_CAN_TIMEOUT;
        printf("   CAN Timeout detected - Using last valid value: %u km\n", lastValidValue);
        currentOdometerValue = lastValidValue;
        return;
    }
    
    if (ValidateOdometerJump(currentOdometerValue, newValue, avgSpeed)) {
        currentOdometerValue = newValue;
        lastValidValue = newValue;
        odometerState = ODOMETER_STATE_NORMAL_OPERATION;
        printf("   Odometer updated to: %u km\n", currentOdometerValue);
    } else {
        odometerState = ODOMETER_STATE_ERROR;
        printf("   Keeping previous value: %u km\n", currentOdometerValue);
        // In real system, would trigger DTC and notify user
    }
    
    printf("   Current state: %s\n", 
           (odometerState == ODOMETER_STATE_NORMAL_OPERATION) ? "NORMAL" :
           (odometerState == ODOMETER_STATE_CAN_TIMEOUT) ? "CAN_TIMEOUT" :
           (odometerState == ODOMETER_STATE_ERROR) ? "ERROR" : "UNKNOWN");
}

void RunDemo(void)
{
    printf("Starting demo scenarios...\n");
    
    // Scenario 1: Normal operation
    printf("\n=== Scenario 1: Normal Operation ===\n");
    ProcessOdometerUpdate(50010, 60, true);  // Normal increment
    ProcessOdometerUpdate(50020, 65, true);  // Normal increment
    
    // Scenario 2: Small acceptable jump
    printf("\n=== Scenario 2: Small Acceptable Jump ===\n");
    ProcessOdometerUpdate(50080, 70, true);  // Acceptable jump due to speed
    
    // Scenario 3: Large unacceptable jump (potential CAN error)
    printf("\n=== Scenario 3: Large Jump Detection ===\n");
    ProcessOdometerUpdate(52000, 75, true);  // Huge jump - should be rejected
    
    // Scenario 4: CAN communication timeout
    printf("\n=== Scenario 4: CAN Communication Timeout ===\n");
    ProcessOdometerUpdate(55000, 0, false);  // CAN timeout - use last valid
    
    // Scenario 5: Recovery from timeout
    printf("\n=== Scenario 5: Recovery from Timeout ===\n");
    ProcessOdometerUpdate(50090, 80, true);  // CAN back online
    
    // Final state
    printf("\n=== Final System State ===\n");
    printf("Final odometer value: %u km\n", currentOdometerValue);
    printf("System state: %s\n", 
           (odometerState == ODOMETER_STATE_NORMAL_OPERATION) ? "NORMAL_OPERATION" :
           (odometerState == ODOMETER_STATE_CAN_TIMEOUT) ? "CAN_TIMEOUT" :
           (odometerState == ODOMETER_STATE_ERROR) ? "ERROR" : "UNKNOWN");
}

void PrintSystemInfo(void)
{
    printf("\n=== System Information ===\n");
    printf("Protection Features:\n");
    printf("  • Jump detection with speed-based validation\n");
    printf("  • CAN timeout handling (1 second)\n");
    printf("  • Moving average speed filtering (%d samples)\n", ODOMETER_SPEED_FILTER_SAMPLES);
    printf("  • NVM backup and recovery\n");
    printf("  • AUTOSAR DET error reporting\n");
    printf("\nThresholds:\n");
    printf("  • Max jump threshold: %u km\n", ODOMETER_MAX_JUMP_THRESHOLD);
    printf("  • Speed filter samples: %u\n", ODOMETER_SPEED_FILTER_SAMPLES);
    printf("  • CAN timeout: 1000 ms\n");
}

int main(void)
{
    PrintHeader();
    PrintSystemInfo();
    RunDemo();
    
    printf("\n========================================\n");
    printf("Demo completed successfully!\n");
    printf("This demonstrates the AUTOSAR IC\n");
    printf("Odometer protection system functionality.\n");
    printf("========================================\n\n");
    
    return 0;
}