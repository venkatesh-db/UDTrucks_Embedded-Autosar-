/*******************************************************************************
 * File: unity_config.h
 * Description: Unity test framework configuration
 *******************************************************************************/

#ifndef UNITY_CONFIG_H
#define UNITY_CONFIG_H

/* Unity configuration settings */
#define UNITY_INCLUDE_DOUBLE
#define UNITY_SUPPORT_64
#define UNITY_INT_WIDTH 32
#define UNITY_LONG_WIDTH 64
#define UNITY_POINTER_WIDTH 64
#define UNITY_SUPPORT_TEST_CASES

#endif /* UNITY_CONFIG_H */