/*******************************************************************************
 * File: debug_test.c
 * Description: Debug test to see exact values
 *******************************************************************************/

#include "unity.h"
#include "OdometerManager.h"
#include "OdometerConfig.h"
#include "mock_NvM.h"
#include "mock_Det.h"

void setUp(void)
{
    mock_NvM_Reset();
    mock_Det_Reset();
    OdometerManager_Reset();
}

void tearDown(void)
{
    /* Cleanup */
}

/* Debug test to see what values are returned */
void test_Debug_Init_Failure(void)
{
    printf("\n=== DEBUG: Testing Init Failure ===\n");
    
    /* Arrange */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_NOT_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    Det_ReportError_Expect(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                          ODOMETER_API_INIT, ODOMETER_E_NVM_READ_FAILED);
    
    printf("Expected E_NOT_OK value: %d\n", E_NOT_OK);
    
    /* Act */
    Std_ReturnType result = OdometerManager_Init();
    
    printf("Actual result: %d\n", result);
    printf("Current state: %d\n", OdometerManager_GetState());
    printf("Expected error state: %d\n", ODOMETER_STATE_ERROR);
    printf("DET Error called: %s\n", mock_Det_WasErrorCalled() ? "YES" : "NO");
    
    /* Assert */
    TEST_ASSERT_EQUAL_MESSAGE(E_NOT_OK, result, "Init should return E_NOT_OK on NVM failure");
    TEST_ASSERT_EQUAL_MESSAGE(ODOMETER_STATE_ERROR, OdometerManager_GetState(), "State should be ERROR on NVM failure");
}

void test_Debug_UpdateValue_NotInitialized(void)
{
    printf("\n=== DEBUG: Testing UpdateValue Not Initialized ===\n");
    
    /* Don't initialize - test uninitialized behavior */
    
    printf("Expected E_NOT_OK value: %d\n", E_NOT_OK);
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(50000, 60);
    
    printf("Actual result: %d\n", result);
    
    /* Assert */
    TEST_ASSERT_EQUAL_MESSAGE(E_NOT_OK, result, "UpdateValue should return E_NOT_OK when not initialized");
}

int main(void)
{
    UNITY_BEGIN();
    
    RUN_TEST(test_Debug_Init_Failure);
    RUN_TEST(test_Debug_UpdateValue_NotInitialized);
    
    return UNITY_END();
}