/*******************************************************************************
 * File: test_OdometerManager.c
 * Description: Unit Tests for AUTOSAR IC Odometer Manager
 * Author: AUTOSAR Development Team
 * Date: November 2025
 * Version: 1.0
 *
 * Purpose: Comprehensive test suite for odometer manager functionality
 *******************************************************************************/

/*******************************************************************************
 * INCLUDES
 *******************************************************************************/
#include "unity.h"
#include "OdometerManager.h"
#include "OdometerConfig.h"  // Added missing config constants
#include "mock_NvM.h"
#include "mock_Det.h"

/*******************************************************************************
 * TEST FIXTURES AND SETUP
 *******************************************************************************/
void setUp(void)
{
    /* Reset the odometer manager and all mocks before each test */
    mock_NvM_Reset();
    mock_Det_Reset();
    OdometerManager_Reset();
}

void tearDown(void)
{
    /* Cleanup after each test */
}

/*******************************************************************************
 * TEST CASES - INITIALIZATION
 *******************************************************************************/
void test_OdometerManager_Init_Success(void)
{
    /* Arrange */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    
    /* Act */
    Std_ReturnType result = OdometerManager_Init();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
}

void test_OdometerManager_Init_NvM_Failure(void)
{
    /* Arrange */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_NOT_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    Det_ReportError_Expect(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                          ODOMETER_API_INIT, ODOMETER_E_NVM_READ_FAILED);
    
    /* Act */
    Std_ReturnType result = OdometerManager_Init();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
    TEST_ASSERT_EQUAL(ODOMETER_STATE_ERROR, OdometerManager_GetState());
}

/*******************************************************************************
 * TEST CASES - VALUE VALIDATION
 *******************************************************************************/
void test_OdometerManager_ValidateValue_NormalIncrement(void)
{
    /* Arrange */
    uint32 currentOdometer = 100000; /* 100km */
    uint16 currentSpeed = 500;       /* 50 km/h */
    uint32 newOdometer = 100100;     /* 100.1km - reasonable increment */
    
    /* Initialize with current values */
    OdometerManager_Init();
    OdometerManager_UpdateValue(currentOdometer, currentSpeed);
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(newOdometer, currentSpeed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    
    uint32 retrievedValue;
    OdometerManager_GetValue(&retrievedValue);
    TEST_ASSERT_EQUAL(newOdometer, retrievedValue);
}

void test_OdometerManager_ValidateValue_LargeJump_Rejected(void)
{
    /* Arrange */
    uint32 currentOdometer = 100000; /* 100km */
    uint16 currentSpeed = 500;       /* 50 km/h */
    uint32 newOdometer = 105000;     /* 105km - unrealistic jump */
    
    Det_ReportError_Expect(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                          ODOMETER_API_UPDATE_VALUE, ODOMETER_E_VALUE_JUMP_DETECTED);
    
    /* Initialize with current values */
    OdometerManager_Init();
    OdometerManager_UpdateValue(currentOdometer, currentSpeed);
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(newOdometer, currentSpeed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
    
    /* Verify original value is maintained */
    uint32 retrievedValue;
    OdometerManager_GetValue(&retrievedValue);
    TEST_ASSERT_EQUAL(currentOdometer, retrievedValue);
}

void test_OdometerManager_ValidateValue_FirstValue_Accepted(void)
{
    /* Arrange */
    uint32 firstOdometer = 50000; /* Any reasonable value should be accepted as first */
    uint16 speed = 0;
    
    /* Act */
    OdometerManager_Init();
    Std_ReturnType result = OdometerManager_UpdateValue(firstOdometer, speed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    
    uint32 retrievedValue;
    OdometerManager_GetValue(&retrievedValue);
    TEST_ASSERT_EQUAL(firstOdometer, retrievedValue);
}

/*******************************************************************************
 * TEST CASES - TIMEOUT HANDLING
 *******************************************************************************/
void test_OdometerManager_Timeout_SingleTimeout(void)
{
    /* Arrange */
    OdometerManager_Init();
    OdometerManager_UpdateValue(100000, 500);
    
    /* Act - Simulate single timeout */
    OdometerManager_HandleCanTimeout();
    
    /* Assert */
    TEST_ASSERT_EQUAL(ODOMETER_STATE_CAN_TIMEOUT, OdometerManager_GetState());
}

void test_OdometerManager_Timeout_MultipleTimeouts(void)
{
    /* Arrange */
    NvM_WriteBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_WriteBlock_IgnoreArg_NvM_SrcPtr();
    
    OdometerManager_Init();
    OdometerManager_UpdateValue(100000, 500);
    
    /* Act - Simulate multiple timeouts */
    OdometerManager_HandleCanTimeout(); /* First timeout */
    OdometerManager_HandleCanTimeout(); /* Second timeout */
    OdometerManager_HandleCanTimeout(); /* Third timeout - should trigger comm lost */
    
    /* Assert */
    TEST_ASSERT_EQUAL(ODOMETER_STATE_COMMUNICATION_LOST, OdometerManager_GetState());
}

void test_OdometerManager_Recovery_AfterTimeout(void)
{
    /* Arrange */
    OdometerManager_Init();
    OdometerManager_UpdateValue(100000, 500);
    OdometerManager_HandleCanTimeout();
    
    /* Act - Recovery with valid data */
    OdometerManager_HandleCanRecovery();
    
    /* Assert */
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
}

/*******************************************************************************
 * TEST CASES - NVM OPERATIONS
 *******************************************************************************/
void test_OdometerManager_SaveToNvm_Success(void)
{
    /* Arrange */
    NvM_WriteBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_WriteBlock_IgnoreArg_NvM_SrcPtr();
    
    OdometerManager_Init();
    OdometerManager_UpdateValue(123456, 600);
    
    /* Act */
    Std_ReturnType result = OdometerManager_SaveToNvm();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
}

void test_OdometerManager_SaveToNvm_Failure(void)
{
    /* Arrange */
    NvM_WriteBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_NOT_OK);
    NvM_WriteBlock_IgnoreArg_NvM_SrcPtr();
    Det_ReportError_Expect(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID, 
                          ODOMETER_API_SAVE_TO_NVM, ODOMETER_E_NVM_WRITE_FAILED);
    
    OdometerManager_Init();
    
    /* Act */
    Std_ReturnType result = OdometerManager_SaveToNvm();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

/*******************************************************************************
 * TEST CASES - ERROR CONDITIONS
 *******************************************************************************/
void test_OdometerManager_GetValue_NullPointer(void)
{
    /* Arrange */
    OdometerManager_Init();
    
    /* Act */
    Std_ReturnType result = OdometerManager_GetValue(NULL);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

void test_OdometerManager_GetValue_NotInitialized(void)
{
    /* Arrange */
    uint32 value;
    /* Don't initialize */
    
    /* Act */
    Std_ReturnType result = OdometerManager_GetValue(&value);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

void test_OdometerManager_UpdateValue_NotInitialized(void)
{
    /* Arrange */
    /* Don't initialize */
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(100000, 500);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

/*******************************************************************************
 * TEST CASES - SPEED FILTERING
 *******************************************************************************/
void test_OdometerManager_SpeedFilter_MovingAverage(void)
{
    /* Arrange */
    OdometerManager_Init();
    
    /* Act - Feed multiple speed values */
    OdometerManager_UpdateValue(100000, 500);  /* 50 km/h */
    OdometerManager_UpdateValue(100010, 520);  /* 52 km/h */
    OdometerManager_UpdateValue(100020, 480);  /* 48 km/h */
    OdometerManager_UpdateValue(100030, 510);  /* 51 km/h */
    OdometerManager_UpdateValue(100040, 490);  /* 49 km/h */
    
    /* Assert - Filtered speed should be close to average (50 km/h) */
    /* This test verifies the internal filtering is working */
    /* Actual implementation would need accessor function for filtered speed */
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
}

/*******************************************************************************
 * TEST CASES - BOUNDARY CONDITIONS
 *******************************************************************************/
void test_OdometerManager_MaxOdometerValue(void)
{
    /* Arrange */
    uint32 maxOdometer = 0xFFFFFFFE; /* Near maximum 32-bit value */
    uint16 speed = 0;
    
    OdometerManager_Init();
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(maxOdometer, speed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    
    uint32 retrievedValue;
    OdometerManager_GetValue(&retrievedValue);
    TEST_ASSERT_EQUAL(maxOdometer, retrievedValue);
}

void test_OdometerManager_ZeroSpeed_ZeroIncrement(void)
{
    /* Arrange */
    uint32 odometer = 100000;
    uint16 speed = 0; /* Vehicle stationary */
    
    OdometerManager_Init();
    OdometerManager_UpdateValue(odometer, speed);
    
    /* Act - Same odometer value with zero speed should be acceptable */
    Std_ReturnType result = OdometerManager_UpdateValue(odometer, speed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
}

/*******************************************************************************
 * TEST CASES - STATE TRANSITIONS
 *******************************************************************************/
void test_OdometerManager_StateTransition_Complete(void)
{
    /* Arrange */
    NvM_WriteBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_WriteBlock_IgnoreArg_NvM_SrcPtr();
    
    OdometerManager_Init();
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
    
    /* Act & Assert - Complete state transition cycle */
    
    /* Normal to Timeout */
    OdometerManager_HandleCanTimeout();
    TEST_ASSERT_EQUAL(ODOMETER_STATE_CAN_TIMEOUT, OdometerManager_GetState());
    
    /* Timeout to Communication Lost */
    OdometerManager_HandleCanTimeout();
    OdometerManager_HandleCanTimeout(); /* Multiple timeouts needed */
    TEST_ASSERT_EQUAL(ODOMETER_STATE_COMMUNICATION_LOST, OdometerManager_GetState());
    
    /* Communication Lost to Normal */
    OdometerManager_HandleCanRecovery();
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
}

/*******************************************************************************
 * MAIN TEST RUNNER
 *******************************************************************************/
int main(void)
{
    UNITY_BEGIN();
    
    /* Initialization Tests */
    RUN_TEST(test_OdometerManager_Init_Success);
    RUN_TEST(test_OdometerManager_Init_NvM_Failure);
    
    /* Value Validation Tests */
    RUN_TEST(test_OdometerManager_ValidateValue_NormalIncrement);
    RUN_TEST(test_OdometerManager_ValidateValue_LargeJump_Rejected);
    RUN_TEST(test_OdometerManager_ValidateValue_FirstValue_Accepted);
    
    /* Timeout Handling Tests */
    RUN_TEST(test_OdometerManager_Timeout_SingleTimeout);
    RUN_TEST(test_OdometerManager_Timeout_MultipleTimeouts);
    RUN_TEST(test_OdometerManager_Recovery_AfterTimeout);
    
    /* NVM Operation Tests */
    RUN_TEST(test_OdometerManager_SaveToNvm_Success);
    RUN_TEST(test_OdometerManager_SaveToNvm_Failure);
    
    /* Error Condition Tests */
    RUN_TEST(test_OdometerManager_GetValue_NullPointer);
    RUN_TEST(test_OdometerManager_GetValue_NotInitialized);
    RUN_TEST(test_OdometerManager_UpdateValue_NotInitialized);
    
    /* Speed Filtering Tests */
    RUN_TEST(test_OdometerManager_SpeedFilter_MovingAverage);
    
    /* Boundary Condition Tests */
    RUN_TEST(test_OdometerManager_MaxOdometerValue);
    RUN_TEST(test_OdometerManager_ZeroSpeed_ZeroIncrement);
    
    /* State Transition Tests */
    RUN_TEST(test_OdometerManager_StateTransition_Complete);
    
    return UNITY_END();
}