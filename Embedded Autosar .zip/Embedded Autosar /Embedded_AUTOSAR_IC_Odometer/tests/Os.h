/*******************************************************************************
 * File: Os.h
 * Description: Simplified Operating System header for testing
 *******************************************************************************/

#ifndef OS_H
#define OS_H

#include "Std_Types.h"

/* OS Task management */
typedef uint8 TaskType;
typedef uint8 EventMaskType;

/* Function declarations */
Std_ReturnType ActivateTask(TaskType TaskID);
Std_ReturnType TerminateTask(void);
Std_ReturnType SetEvent(TaskType TaskID, EventMaskType Mask);
Std_ReturnType ClearEvent(EventMaskType Mask);
Std_ReturnType WaitEvent(EventMaskType Mask);

#endif /* OS_H */