/*******************************************************************************
 * File: CanIf.h  
 * Description: Simplified CAN Interface header for testing
 *******************************************************************************/

#ifndef CANIF_H
#define CANIF_H

#include "Std_Types.h"

/* CAN Interface types */
typedef enum {
    CANIF_OFFLINE = 0,
    CANIF_TX_OFFLINE,
    CANIF_TX_OFFLINE_ACTIVE,
    CANIF_ONLINE
} CanIf_PduModeType;

/* Function declarations */
Std_ReturnType CanIf_SetPduMode(NetworkHandleType Controller, CanIf_PduModeType PduModeRequest);
Std_ReturnType CanIf_GetPduMode(NetworkHandleType Controller, CanIf_PduModeType* PduModePtr);

#endif /* CANIF_H */