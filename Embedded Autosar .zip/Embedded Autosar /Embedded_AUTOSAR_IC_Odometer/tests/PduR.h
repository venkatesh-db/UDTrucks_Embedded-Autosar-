/*******************************************************************************
 * File: PduR.h
 * Description: Simplified PDU Router header for testing  
 *******************************************************************************/

#ifndef PDUR_H
#define PDUR_H

#include "Std_Types.h"

/* PDU Router types */
typedef enum {
    PDUR_ONLINE = 0,
    PDUR_REDUCED,
    PDUR_OFFLINE
} PduR_StateType;

/* Function declarations */
void PduR_ComTransmit(PduIdType TxPduId, const PduInfoType* PduInfoPtr);

#endif /* PDUR_H */