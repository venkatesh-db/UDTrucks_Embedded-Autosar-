/*******************************************************************************
 * File: simple_test.c
 * Description: Simple test to verify basic functionality
 *******************************************************************************/

#include "unity.h"
#include "Std_Types.h"
#include "OdometerConfig.h"

/* Simple test setup */
void setUp(void)
{
    /* Setup code */
}

void tearDown(void)
{
    /* Cleanup code */
}

/* Basic test cases */
void test_BasicConstants(void)
{
    TEST_ASSERT_EQUAL(100U, ODOMETER_MODULE_ID);
    TEST_ASSERT_EQUAL(0U, ODOMETER_INSTANCE_ID);
}

void test_ErrorCodes(void)
{
    TEST_ASSERT_EQUAL(0x01U, ODOMETER_E_UNINIT);
    TEST_ASSERT_EQUAL(0x04U, ODOMETER_E_NVM_READ_FAILED);
    TEST_ASSERT_EQUAL(0x06U, ODOMETER_E_VALUE_JUMP_DETECTED);
}

/* Main test runner */
int main(void)
{
    UNITY_BEGIN();
    
    RUN_TEST(test_BasicConstants);
    RUN_TEST(test_ErrorCodes);
    
    return UNITY_END();
}