/*******************************************************************************
 * File: Det.h
 * Description: Simplified Development Error Tracer header for testing
 *******************************************************************************/

#ifndef DET_H
#define DET_H

#include "Std_Types.h"

/* DET Error reporting functions */
void Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);
void Det_ReportRuntimeError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);

#endif /* DET_H */