/*******************************************************************************
 * Simple test to check enum values
 *******************************************************************************/

#include <stdio.h>
#include "OdometerManager.h"
#include "OdometerConfig.h"
#include "Std_Types.h"

int main(void)
{
    printf("=== ENUM VALUE CHECK ===\n");
    printf("E_OK = %d\n", E_OK);
    printf("E_NOT_OK = %d\n", E_NOT_OK);
    printf("ODOMETER_STATE_INIT = %d\n", ODOMETER_STATE_INIT);
    printf("ODOMETER_STATE_NORMAL_OPERATION = %d\n", ODOMETER_STATE_NORMAL_OPERATION);
    printf("ODOMETER_STATE_CAN_TIMEOUT = %d\n", ODOMETER_STATE_CAN_TIMEOUT);
    printf("ODOMETER_STATE_COMMUNICATION_LOST = %d\n", ODOMETER_STATE_COMMUNICATION_LOST);
    printf("ODOMETER_STATE_ERROR = %d\n", ODOMETER_STATE_ERROR);
    
    return 0;
}