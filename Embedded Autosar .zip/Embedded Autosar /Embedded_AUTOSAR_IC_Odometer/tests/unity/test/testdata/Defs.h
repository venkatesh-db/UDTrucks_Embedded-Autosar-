/* =========================================================================
    Unity - A Test Framework for C
    ThrowTheSwitch.org
    Copyright (c) 2007-25 Mike Karlesky, Mark VanderVoord, & Greg Williams
    SPDX-License-Identifier: MIT
========================================================================= */

#ifndef DEF_H
#define DEF_H

#define EXTERN_DECL

extern int CounterSuiteSetup;
extern int isArgumentOne(int i);

#endif
