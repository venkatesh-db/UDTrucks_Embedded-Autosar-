/*******************************************************************************
 * File: ComM.h
 * Description: Simplified Communication Manager header for testing
 *******************************************************************************/

#ifndef COMM_H
#define COMM_H

#include "Std_Types.h"

/* Network Handle Type */
typedef uint8 NetworkHandleType;

/* Communication Manager types */
typedef enum {
    COMM_NO_COMMUNICATION = 0,
    COMM_SILENT_COMMUNICATION,
    COMM_FULL_COMMUNICATION
} ComM_ModeType;

/* Function declarations */
Std_ReturnType ComM_RequestComMode(NetworkHandleType Channel, ComM_ModeType ComMode);
Std_ReturnType ComM_GetCurrentComMode(NetworkHandleType Channel, ComM_ModeType* ComMode);

#endif /* COMM_H */