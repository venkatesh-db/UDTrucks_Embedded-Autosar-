/*******************************************************************************
 * File: working_test.c  
 * Description: Fixed and working test cases
 *******************************************************************************/

#include "unity.h"
#include "OdometerManager.h"
#include "OdometerConfig.h" 
#include "mock_NvM.h"
#include "mock_Det.h"

void setUp(void)
{
    mock_NvM_Reset();
    mock_Det_Reset();
}

void tearDown(void)
{
    /* Cleanup */
}

/* Working test cases */
void test_OdometerManager_Init_Success(void)
{
    /* Arrange */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    
    /* Act */
    Std_ReturnType result = OdometerManager_Init();
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
    TEST_ASSERT_EQUAL(ODOMETER_STATE_NORMAL_OPERATION, OdometerManager_GetState());
}

void test_OdometerManager_ValidateValue_NormalIncrement(void)
{
    /* Arrange - Initialize first */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    OdometerManager_Init();
    
    uint32 currentOdometer = 100000; 
    uint16 currentSpeed = 500;       
    uint32 newOdometer = 100100;     
    
    OdometerManager_UpdateValue(currentOdometer, currentSpeed);
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(newOdometer, currentSpeed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
}

void test_OdometerManager_ValidateValue_LargeJump_Rejected(void)
{
    /* Arrange - Initialize first */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    OdometerManager_Init();
    
    uint32 currentOdometer = 100000;
    uint16 currentSpeed = 500;
    uint32 largeJumpOdometer = 200000; /* 100km jump - should be rejected */
    
    OdometerManager_UpdateValue(currentOdometer, currentSpeed);
    
    /* Expect DET error for large jump */
    Det_ReportError_Expect(ODOMETER_MODULE_ID, ODOMETER_INSTANCE_ID,
                          ODOMETER_API_UPDATE_VALUE, ODOMETER_E_VALUE_JUMP_DETECTED);
    
    /* Act */
    Std_ReturnType result = OdometerManager_UpdateValue(largeJumpOdometer, currentSpeed);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

void test_OdometerManager_UpdateValue_NotInitialized(void)
{
    /* Arrange - DON'T initialize */
    uint32 odometerValue = 50000;
    uint16 speedValue = 60;
    
    /* Act */  
    Std_ReturnType result = OdometerManager_UpdateValue(odometerValue, speedValue);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_NOT_OK, result);
}

void test_OdometerManager_GetValue_Success(void)
{
    /* Arrange */
    NvM_ReadBlock_ExpectAndReturn(ODOMETER_NVM_BLOCK_ID, NULL, E_OK);
    NvM_ReadBlock_IgnoreArg_NvM_DstPtr();
    OdometerManager_Init();
    
    uint32 odometerValue;
    
    /* Act */
    Std_ReturnType result = OdometerManager_GetValue(&odometerValue);
    
    /* Assert */
    TEST_ASSERT_EQUAL(E_OK, result);
}

int main(void)
{
    UNITY_BEGIN();
    
    RUN_TEST(test_OdometerManager_Init_Success);
    RUN_TEST(test_OdometerManager_ValidateValue_NormalIncrement);  
    RUN_TEST(test_OdometerManager_ValidateValue_LargeJump_Rejected);
    RUN_TEST(test_OdometerManager_UpdateValue_NotInitialized);
    RUN_TEST(test_OdometerManager_GetValue_Success);
    
    return UNITY_END();
}